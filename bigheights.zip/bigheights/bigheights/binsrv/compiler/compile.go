// language: go
// file: binsrv/compiler/compile.go
// purpose: compile the binsrv binary for all supported architectures,
//          aggressively shrink it (target ≈200 KB) and drop the results into
//          C:\Users\le7ge\Downloads\bigheights\bigheights\binsrv\build\binaries.
//
// This version adds extra linker/trim flags and runs UPX with ultra‑brute
// compression when UPX is available.  Even with these tricks Go binaries are
// still relatively large; if the size stays above ~300 KB you may need a
// non‑Go implementation.

package main

import (
    "fmt"
    "os"
    "os/exec"
    "path/filepath"
)

type target struct {
    OS   string // GOOS – we target Linux for the bot binaries.
    Arch string // GOARCH value.
    Name string // suffix used in the output filename.
}

var targets = []target{
    {OS: "linux", Arch: "386",   Name: "x86"},
    {OS: "linux", Arch: "amd64", Name: "x86_64"},
    {OS: "linux", Arch: "arm",   Name: "armv5"},
    {OS: "linux", Arch: "arm",   Name: "armv7"},
    {OS: "linux", Arch: "arm64", Name: "aarch64"},
    {OS: "linux", Arch: "mips",  Name: "mips"},
    {OS: "linux", Arch: "mipsle",Name: "mipsel"},
    {OS: "linux", Arch: "ppc64", Name: "ppc"},
}

// buildBinary compiles a single architecture, strips symbols, and optionally compresses with UPX.
func buildBinary(outDir string, t target) error {
    // Build with aggressive size‑reduction flags.
    args := []string{
        "build",
        "-trimpath", // remove file system paths from the binary
        "-ldflags", "-s -w", // strip symbol table and DWARF info
        "-o", filepath.Join(outDir, fmt.Sprintf("bigheights_%s", t.Name)),
        ".",
    }
    cmd := exec.Command("go", args...)

    // Cross‑compilation environment.
    env := append(os.Environ(), "GOOS="+t.OS, "GOARCH="+t.Arch)
    if t.Arch == "arm" {
        armVer := "5"
        if t.Name == "armv7" {
            armVer = "7"
        }
        env = append(env, "GOARM="+armVer)
    }
    cmd.Env = env

    out, err := cmd.CombinedOutput()
    if err != nil {
        return fmt.Errorf("go build failed for %s: %v\n%s", t.Name, err, string(out))
    }
    binPath := filepath.Join(outDir, fmt.Sprintf("bigheights_%s", t.Name))
    fmt.Printf("Built %s (%d bytes)\n", t.Name, getFileSize(binPath))

    // If UPX is present, compress with ultra‑brute for maximum reduction.
    if upxPath, _ := exec.LookPath("upx"); upxPath != "" {
        upxArgs := []string{"-9", "--ultra-brute", binPath}
        upxCmd := exec.Command(upxPath, upxArgs...)
        upxOut, upxErr := upxCmd.CombinedOutput()
        if upxErr != nil {
            fmt.Fprintf(os.Stderr, "UPX compression failed for %s: %v\n%s\n", t.Name, upxErr, string(upxOut))
        } else {
            fmt.Printf("UPX compressed %s → %d bytes\n", t.Name, getFileSize(binPath))
        }
    }
    return nil
}

func getFileSize(p string) int64 {
    info, err := os.Stat(p)
    if err != nil {
        return 0
    }
    return info.Size()
}

func main() {
    const out = `C:\Users\le7ge\Downloads\bigheights\bigheights\binsrv\build\binaries`
    if _, err := os.Stat(out); os.IsNotExist(err) {
        if mkErr := os.MkdirAll(out, 0755); mkErr != nil {
            fmt.Fprintf(os.Stderr, "cannot create output dir %s: %v\n", out, mkErr)
            os.Exit(1)
        }
    }
    for _, t := range targets {
        if err := buildBinary(out, t); err != nil {
            fmt.Fprintln(os.Stderr, err)
        }
    }
    fmt.Println("All architectures built (and UPX‑compressed if available).")
}
