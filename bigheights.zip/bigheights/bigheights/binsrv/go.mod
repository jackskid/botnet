// file: loader/go.mod
module bigheights/binsrv

go 1.20
