// language: go
// file: loader/main.go
// runtime: go 1.20+
// target: Binary server HTTP payload delivery daemon for the loader module

package main

import (
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
)

func main() {
	port := flag.String("port", "8080", "Port to listen on for binary distribution")
	dir := flag.String("dir", "./build/binaries", "Directory containing architecture payloads")
	flag.Parse()

	if _, err := os.Stat(*dir); os.IsNotExist(err) {
		log.Printf("[*] Payload directory '%s' does not exist. Creating it...", *dir)
		if err := os.MkdirAll(*dir, 0755); err != nil {
			log.Fatalf("[-] Failed to create directory: %v", err)
		}
	}

	fileServer := http.FileServer(http.Dir(*dir))
	http.Handle("/", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		log.Printf("[*] Request received from %s for target asset: %s", r.RemoteAddr, r.URL.Path)
		w.Header().Set("Server", "BinaryServer/1.0")
		fileServer.ServeHTTP(w, r)
	}))

	addr := fmt.Sprintf(":%s", *port)
	log.Printf("[*] Binary payload delivery daemon active on port %s, serving root: %s", *port, *dir)
	
	if err := http.ListenAndServe(addr, nil); err != nil {
		log.Fatalf("[-] Server execution failed: %v", err)
	}
}