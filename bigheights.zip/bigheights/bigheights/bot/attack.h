// language: c
// file: bot/connection.h
// runtime: gcc / cross-compiled via make scripts
// target: C-based network connection and task-loop header declarations

#ifndef BH_CONNECTION_H
#define BH_CONNECTION_H

#include <stdint.h>
#include <sys/types.h>

typedef struct {
    char arch[32];
    int cores;
    int ram_mb;
    int rooted;
    char country[8];
} bh_attrs_t;

int bh_connect(const char *host, uint16_t port, int timeout_sec);
int bh_send_all(int fd, const void *buf, size_t len);
void bh_task_loop(int fd);

#endif