// language: c
// file: bot/connection.h
// runtime: gcc / cross-compiled via make scripts
// target: C-based network connection and task loop interface

#ifndef BH_CONNECTION_H
#define BH_CONNECTION_H

#include <stdint.h>
#include <sys/types.h>

int bh_connect(const char *host, uint16_t port, int timeout_sec);
int bh_send_all(int fd, const void *buf, size_t len);
void bh_task_loop(int fd);

#endif