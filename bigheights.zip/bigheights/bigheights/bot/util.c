// language: c
// file: bot/util.c
// runtime: gcc / cross-compiled via make scripts
// target: C-based utility helpers and string/system support functions

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "util.h"

// Safe string duplication utility fallback
char *bh_strdup(const char *s) {
    if (!s) return NULL;
    size_t len = strlen(s) + 1;
    char *p = malloc(len);
    if (p) {
        memcpy(p, s, len);
    }
    return p;
}

// Memory sanitization helper
void *bh_memset_s(void *v, int c, size_t n) {
    volatile unsigned char *p = v;
    while (n--) {
        *p++ = (unsigned char)c;
    }
    return v;
}