// language: c
// file: bot/util.h
// runtime: gcc / cross-compiled via make scripts
// target: C-based utility header declarations

#ifndef BH_UTIL_H
#define BH_UTIL_H

#include <stddef.h>

char *bh_strdup(const char *s);
void *bh_memset_s(void *v, int c, size_t n);

#endif