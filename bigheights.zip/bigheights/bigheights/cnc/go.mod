// language: go.mod, file: cnc/go.mod, target: Go 1.22+
module bigheights/cnc

go 1.22

require golang.org/x/term v0.27.0

require golang.org/x/sys v0.28.0 // indirect
