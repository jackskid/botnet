// language: Go, file: cnc/internal/auth/apikey.go
// *API key store for :3434. constant-time compare, load once, never log the key*
package auth

import (
	"crypto/subtle"
	"errors"
	"net/http"
	"strings"
	"sync"
)

// Key is one issued API credential.
type Key struct {
	Value string // stored as given; compared constant-time
	Label string // human label for logs / audit ("reseller-A", "panel")
}

// Store holds valid keys.
type Store struct {
	mu   sync.RWMutex
	keys []Key
}

// NewStore returns an empty key store.
func NewStore() *Store { return &Store{} }

// Load replaces the key set from a slice of "value:label" pairs.
func (s *Store) Load(pairs []string) error {
	out := make([]Key, 0, len(pairs))
	for _, p := range pairs {
		p = strings.TrimSpace(p)
		if p == "" {
			continue
		}
		val, label := p, ""
		if i := strings.IndexByte(p, ':'); i >= 0 {
			val, label = p[:i], p[i+1:]
		}
		if len(val) < 16 {
			return errors.New("api key too short (min 16 chars)")
		}
		if label == "" {
			label = "key"
		}
		out = append(out, Key{Value: val, Label: label})
	}
	if len(out) == 0 {
		return errors.New("no api keys loaded")
	}
	s.mu.Lock()
	s.keys = out
	s.mu.Unlock()
	return nil
}

// Valid reports whether the presented key matches any issued key.
// Constant-time over every stored key to avoid timing leaks.
func (s *Store) Valid(presented string) (label string, ok bool) {
	if presented == "" {
		return "", false
	}
	s.mu.RLock()
	defer s.mu.RUnlock()
	var matched int
	var matchedLabel string
	for _, k := range s.keys {
		eq := subtle.ConstantTimeCompare([]byte(presented), []byte(k.Value))
		// eq is 1 when equal. record label without branching out early.
		if eq == 1 && matched == 0 {
			matched = 1
			matchedLabel = k.Label
		}
	}
	return matchedLabel, matched == 1
}

// Middleware wraps an http.Handler, requiring a valid API key.
// Accepts "Authorization: Bearer <key>" or "X-API-Key: <key>".
func (s *Store) Middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		key := extractKey(r)
		if _, ok := s.Valid(key); !ok {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusUnauthorized)
			_, _ = w.Write([]byte(`{"error":"unauthorized"}`))
			return
		}
		next.ServeHTTP(w, r)
	})
}

// extractKey pulls the key from headers or the query string.
func extractKey(r *http.Request) string {
	if h := r.Header.Get("Authorization"); h != "" {
		const p = "Bearer "
		if strings.HasPrefix(h, p) {
			return h[len(p):]
		}
		return h
	}
	if h := r.Header.Get("X-API-Key"); h != "" {
		return h
	}
	return r.URL.Query().Get("key")
}