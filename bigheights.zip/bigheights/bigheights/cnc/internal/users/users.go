// language: Go, file: cnc/internal/users/users.go
// *account store: add/del, expiry, per-user limits, ban, timeout, global hold*
package users

import (
	"errors"
	"fmt"
	"strings"
	"sync"
	"time"
)

// Role tiers — owner is the only admin, users are the operator accounts.
const (
	RoleOwner = "owner"
	RoleUser  = "user"
)

// User is one account on the CNC.
type User struct {
	Name       string
	Pass       string // plain — internal CNC, not a public service
	Role       string
	Expires    time.Time // zero = never
	MaxTime    int       // max attack duration seconds, 0 = unlimited
	NetSize    int       // max bots this user may target, 0 = all
	Banned     bool
	BanReason  string
	BanAppeal  bool
	TimeoutEnd time.Time // zero = not timed out
	TimeoutWhy string
}

// Store holds all accounts plus the global hold flag.
type Store struct {
	mu    sync.RWMutex
	users map[string]*User // key: lowercase name
	hold  bool             // hold bots: block new + running attacks
}

// NewStore returns an empty store.
func NewStore() *Store { return &Store{users: map[string]*User{}} }

// SeedOwner creates the owner account if the store is empty.
func (s *Store) SeedOwner(name, pass string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.users) == 0 {
		s.users[strings.ToLower(name)] = &User{
			Name: name, Pass: pass, Role: RoleOwner,
		}
	}
}

// Add creates a user. name uniqueness checked case-insensitively.
// expiry is a duration from now; 0 means never expires.
func (s *Store) Add(name, pass string, expiry time.Duration, maxTime, netSize int) error {
	if name == "" || pass == "" {
		return errors.New("name and password required")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	key := strings.ToLower(name)
	if _, exists := s.users[key]; exists {
		return fmt.Errorf("user %q already exists", name)
	}
	u := &User{Name: name, Pass: pass, Role: RoleUser, MaxTime: maxTime, NetSize: netSize}
	if expiry > 0 {
		u.Expires = time.Now().Add(expiry)
	}
	s.users[key] = u
	return nil
}

// Delete removes a user by name.
func (s *Store) Delete(name string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	key := strings.ToLower(name)
	if _, ok := s.users[key]; !ok {
		return false
	}
	delete(s.users, key)
	return true
}

// Get returns a copy of the user by name.
func (s *Store) Get(name string) (*User, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	u, ok := s.users[strings.ToLower(name)]
	if !ok {
		return nil, false
	}
	cp := *u
	return &cp, true
}

// Authenticate validates credentials and gate state.
// Returns the user and an error describing the reason for failure.
func (s *Store) Authenticate(name, pass string) (*User, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	u, ok := s.users[strings.ToLower(name)]
	if !ok || u.Pass != pass {
		return nil, errors.New("invalid credentials")
	}
	if u.Banned {
		return nil, &BanError{Reason: u.BanReason, Appeal: u.BanAppeal}
	}
	if !u.TimeoutEnd.IsZero() && time.Now().Before(u.TimeoutEnd) {
		return nil, &TimeoutError{Reason: u.TimeoutWhy, Until: u.TimeoutEnd}
	}
	if !u.Expires.IsZero() && time.Now().After(u.Expires) {
		return nil, errors.New("account expired")
	}
	cp := *u
	return &cp, nil
}

// Ban marks a user banned.
func (s *Store) Ban(name, reason string, appeal bool) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	u, ok := s.users[strings.ToLower(name)]
	if !ok || u.Role == RoleOwner {
		return false
	}
	u.Banned = true
	u.BanReason = reason
	u.BanAppeal = appeal
	return true
}

// Timeout places a user in timeout for a duration.
func (s *Store) Timeout(name string, d time.Duration, reason string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	u, ok := s.users[strings.ToLower(name)]
	if !ok || u.Role == RoleOwner {
		return false
	}
	u.TimeoutEnd = time.Now().Add(d)
	u.TimeoutWhy = reason
	return true
}

// Hold reports the global hold flag. When true the CNC refuses to accept
// new attacks, and running attacks are cleared.
func (s *Store) Hold() bool {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.hold
}

// SetHold flips the global hold flag, returns new state.
func (s *Store) SetHold(on bool) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.hold = on
	return s.hold
}

// List returns all accounts (sans password) for admin views.
func (s *Store) List() []User {
	s.mu.RLock()
	defer s.mu.RUnlock()
	out := make([]User, 0, len(s.users))
	for _, u := range s.users {
		cp := *u
		cp.Pass = ""
		out = append(out, cp)
	}
	return out
}

// ---- typed errors for the login gate ----

// BanError is returned to a banned user on login attempt.
type BanError struct {
	Reason string
	Appeal bool
}

func (e *BanError) Error() string { return "banned: " + e.Reason }

// TimeoutError is returned to a timed-out user on login attempt.
type TimeoutError struct {
	Reason string
	Until  time.Time
}

func (e *TimeoutError) Error() string { return "timed out: " + e.Reason }

// Remaining formats the timeout remaining as "HH:MM:SS".
func (e *TimeoutError) Remaining() string {
	d := time.Until(e.Until)
	if d < 0 {
		return "0s"
	}
	h := int(d.Hours())
	m := int(d.Minutes()) % 60
	sec := int(d.Seconds()) % 60
	return fmt.Sprintf("%02d:%02d:%02d", h, m, sec)
}